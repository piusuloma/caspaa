/* ============================================================
   TEACHER MODULE
   ============================================================ */

/* ---------- Self clock-in / clock-out ---------- */
function todaysClockRecord(staffId) {
  return DB.query('staffAttendance', a => a.staffId === staffId && a.date === today())[0];
}

function renderClockInCard(staffId) {
  const rec = todaysClockRecord(staffId);
  if (!rec) {
    // Not clocked in yet
    return `<div class="bg-white/15 backdrop-blur rounded-2xl p-4 lg:min-w-[260px]">
      <div class="text-brand-200 text-xs uppercase font-semibold mb-1">Not clocked in</div>
      <div class="text-2xl font-bold mb-2">${new Date().toTimeString().slice(0,5)}</div>
      <button class="bg-white text-brand-700 px-5 py-2.5 rounded-xl font-bold w-full text-sm hover:bg-brand-50" onclick="staffClockIn()">${icon('check','w-4 h-4 inline')} Clock In Now</button>
    </div>`;
  }
  if (rec.clockOut) {
    // Done for the day
    const inH = parseInt(rec.clockIn.split(':')[0]);
    const inM = parseInt(rec.clockIn.split(':')[1]);
    const outH = parseInt(rec.clockOut.split(':')[0]);
    const outM = parseInt(rec.clockOut.split(':')[1]);
    const mins = (outH * 60 + outM) - (inH * 60 + inM);
    const hrs = Math.floor(mins / 60);
    const minsLeft = mins % 60;
    return `<div class="bg-emerald-500/30 backdrop-blur rounded-2xl p-4 lg:min-w-[260px]">
      <div class="text-emerald-100 text-xs uppercase font-semibold mb-1">${icon('check','w-3 h-3 inline')} Day complete</div>
      <div class="text-2xl font-bold mb-1">${hrs}h ${minsLeft}m</div>
      <div class="text-xs text-emerald-100">${rec.clockIn} → ${rec.clockOut}</div>
    </div>`;
  }
  // Clocked in, not clocked out yet
  return `<div class="bg-white/15 backdrop-blur rounded-2xl p-4 lg:min-w-[260px]">
    <div class="text-brand-200 text-xs uppercase font-semibold mb-1">Clocked in at ${rec.clockIn}${rec.status === 'late' ? ' · <span class="text-amber-200 font-bold">LATE</span>' : ''}</div>
    <div class="text-2xl font-bold mb-2">${new Date().toTimeString().slice(0,5)}</div>
    <button class="bg-rose-500 text-white px-5 py-2.5 rounded-xl font-bold w-full text-sm hover:bg-rose-600" onclick="staffClockOut()">${icon('logout','w-4 h-4 inline')} Clock Out</button>
  </div>`;
}

function staffClockIn() {
  const staffId = AUTH.current.id;
  const existing = todaysClockRecord(staffId);
  if (existing) { toast('Already clocked in today', 'warn'); return; }
  const clockIn = new Date().toTimeString().slice(0, 5);
  const [h, m] = clockIn.split(':').map(Number);
  // Anything after 08:00 counts as late (configurable in real product)
  const status = (h >= 8 && m > 0) || h >= 9 ? 'late' : 'present';
  DB.insert('staffAttendance', {
    id: uid('satt'), schoolId: AUTH.current.schoolId || 'sch_brightlights',
    staffId, date: today(),
    clockIn, clockOut: null,
    status, source: 'self'
  });
  DB.insert('auditLog', { id: uid('aud'), schoolId: AUTH.current.schoolId || 'sch_brightlights', actor: staffId, action: 'staff_clock_in', target: `${clockIn}${status === 'late' ? ' (late)' : ''}`, timestamp: now() });
  toast(`Clocked in at ${clockIn}${status === 'late' ? ' · marked late' : ''}`, status === 'late' ? 'warn' : 'success');
  APP.render();
}

function staffClockOut() {
  const staffId = AUTH.current.id;
  const rec = todaysClockRecord(staffId);
  if (!rec) { toast("You haven't clocked in today", 'danger'); return; }
  const clockOut = new Date().toTimeString().slice(0, 5);
  DB.update('staffAttendance', rec.id, { clockOut });
  DB.insert('auditLog', { id: uid('aud'), schoolId: rec.schoolId, actor: staffId, action: 'staff_clock_out', target: clockOut, timestamp: now() });
  toast(`Clocked out at ${clockOut}. Have a good evening.`, 'success');
  APP.render();
}

/* ---------- Substitute coverage acceptance widget ---------- */
function renderSubstituteRequestsWidget(staffId) {
  const requests = DB.query('substituteCoverage', c => c.substituteTeacherId === staffId);
  const pending = requests.filter(c => c.status === 'pending' || !c.status);
  const upcoming = requests.filter(c => c.status === 'accepted' && new Date(c.from) >= new Date());
  if (pending.length === 0 && upcoming.length === 0) return '';
  return `
    <div class="card p-5 border-l-4 border-amber-500">
      <h3 class="font-bold text-slate-900 mb-3">${pending.length ? '⚠️ Substitute Coverage Requested' : 'Upcoming Coverage'}</h3>
      <div class="space-y-2">
        ${pending.map(c => {
          const original = DB.find('teachers', c.originalTeacherId);
          const days = Math.ceil((new Date(c.to) - new Date(c.from)) / 86400000) + 1;
          return `<div class="p-3 bg-amber-50 rounded-xl">
            <div class="text-sm">
              <strong>${original ? original.name : 'A colleague'}</strong> needs coverage from <strong>${fdate(c.from, { long: true })}</strong> to <strong>${fdate(c.to, { long: true })}</strong> (${days} days).
            </div>
            <div class="text-xs text-slate-600 mt-1">Their classes will be added to your timetable for that period.</div>
            <div class="flex gap-2 mt-3">
              <button class="btn btn-primary !py-1.5 text-sm" onclick="decideSubstituteCoverage('${c.id}', 'accepted')">${icon('check','w-3.5 h-3.5')} Accept</button>
              <button class="btn btn-secondary !py-1.5 text-sm" onclick="decideSubstituteCoverage('${c.id}', 'declined')">${icon('x','w-3.5 h-3.5')} Decline</button>
            </div>
          </div>`;
        }).join('')}
        ${upcoming.map(c => {
          const original = DB.find('teachers', c.originalTeacherId);
          return `<div class="p-3 bg-emerald-50 rounded-xl text-sm">
            ${icon('check','w-4 h-4 inline text-emerald-700')} Covering for <strong>${original ? original.name : 'colleague'}</strong> · ${fdate(c.from, { short: true })} – ${fdate(c.to, { short: true })}
          </div>`;
        }).join('')}
      </div>
    </div>
  `;
}

/* ---------- Teacher self-service Leave Request ---------- */
function renderMyLeaveWidget(staffId) {
  const myLeaves = DB.query('leaveRequests', l => l.staffId === staffId).sort((a, b) => b.requestedAt.localeCompare(a.requestedAt));
  const pending = myLeaves.filter(l => l.status === 'pending').length;
  const upcoming = myLeaves.filter(l => l.status === 'approved' && new Date(l.from) >= new Date()).length;
  return `
    <div class="card p-5">
      <div class="flex items-center justify-between mb-3">
        <h3 class="font-bold text-slate-900">My Leave</h3>
        <button class="btn btn-primary text-sm" onclick="requestLeaveModal()">${icon('plus','w-3.5 h-3.5')} Request Leave</button>
      </div>
      ${myLeaves.length === 0
        ? `<p class="text-sm text-slate-500">You have no leave requests on file. Click <strong>Request Leave</strong> to submit one.</p>`
        : `<div class="grid grid-cols-3 gap-2 mb-3 text-center text-sm">
            <div class="bg-amber-50 rounded-lg p-2"><div class="text-xs text-amber-700">Pending</div><div class="font-bold text-amber-900">${pending}</div></div>
            <div class="bg-emerald-50 rounded-lg p-2"><div class="text-xs text-emerald-700">Upcoming</div><div class="font-bold text-emerald-900">${upcoming}</div></div>
            <div class="bg-blue-50 rounded-lg p-2"><div class="text-xs text-blue-700">Total this year</div><div class="font-bold text-blue-900">${myLeaves.length}</div></div>
          </div>
          <div class="space-y-1.5">
            ${myLeaves.slice(0, 4).map(l => {
              const days = Math.ceil((new Date(l.to) - new Date(l.from)) / 86400000) + 1;
              return `<div class="flex items-center gap-2 p-2 bg-slate-50 rounded-lg">
                <span class="badge ${l.status === 'approved' ? 'badge-success' : l.status === 'rejected' ? 'badge-danger' : 'badge-warn'}">${l.status}</span>
                <div class="flex-1 min-w-0">
                  <div class="text-sm font-semibold">${l.type} Leave · ${days}d</div>
                  <div class="text-xs text-slate-500">${fdate(l.from, { short: true })} – ${fdate(l.to, { short: true })}</div>
                </div>
              </div>`;
            }).join('')}
          </div>`}
    </div>
  `;
}

function requestLeaveModal() {
  modal({
    title: 'Request Leave',
    body: `
      <div class="space-y-3">
        <div class="bg-blue-50 border border-blue-200 rounded-xl p-3 text-sm text-blue-900">
          Your request goes to the proprietor / HR for approval. They'll typically respond within 24 hours. You'll be notified on the bell icon.
        </div>
        <div>
          <label class="input-label">Leave Type</label>
          <select id="lvreq_type" class="input">
            <option>Casual</option>
            <option>Sick</option>
            <option>Annual</option>
            <option>Maternity</option>
            <option>Bereavement</option>
            <option>Study</option>
            <option>Compassionate</option>
          </select>
        </div>
        <div class="grid grid-cols-2 gap-3">
          <div><label class="input-label">From</label><input id="lvreq_from" type="date" class="input" value="${daysAhead(7)}" /></div>
          <div><label class="input-label">To</label><input id="lvreq_to" type="date" class="input" value="${daysAhead(8)}" /></div>
        </div>
        <div>
          <label class="input-label">Reason</label>
          <textarea id="lvreq_reason" rows="3" class="input" placeholder="A brief note for the approver…"></textarea>
        </div>
        <div class="bg-slate-50 rounded-xl p-3 text-xs text-slate-600">
          ${icon('check','w-3 h-3 inline')} A substitute teacher for your classes will be suggested automatically once approved.
        </div>
      </div>
    `,
    footer: `<button class="btn btn-secondary" onclick="document.getElementById('modalBackdrop').click()">Cancel</button>
             <button class="btn btn-primary" onclick="submitMyLeaveRequest()">${icon('send','w-4 h-4')} Submit Request</button>`
  });
}

function submitMyLeaveRequest() {
  const type = document.getElementById('lvreq_type').value;
  const from = document.getElementById('lvreq_from').value;
  const to = document.getElementById('lvreq_to').value;
  const reason = document.getElementById('lvreq_reason').value.trim();
  if (!from || !to) { toast('From and To dates required', 'danger'); return; }
  if (new Date(to) < new Date(from)) { toast('"To" date must be after "From" date', 'danger'); return; }
  const t = DB.find('teachers', AUTH.current.id) || {};
  DB.insert('leaveRequests', {
    id: uid('lv'),
    schoolId: t.schoolId || 'sch_brightlights',
    staffId: AUTH.current.id,
    type, from, to, reason,
    status: 'pending',
    source: 'self',
    requestedAt: now()
  });
  DB.insert('auditLog', { id: uid('aud'), schoolId: t.schoolId || 'sch_brightlights', actor: AUTH.current.id, action: 'requested_leave', target: `${type} leave ${fdate(from,{short:true})}–${fdate(to,{short:true})}`, timestamp: now() });
  // Notify proprietor (school admin)
  DB.insert('notifications', { id: uid('not'), userId: t.schoolId || 'sch_brightlights', title: 'Leave Request', body: `${AUTH.current.name} is requesting ${type.toLowerCase()} leave from ${fdate(from,{long:true})} to ${fdate(to,{long:true})}.`, type: 'info', read: false, timestamp: now(), link: { view: 'adm_workforce', params: { workforceTab: 'hr', hrTab: 'leave' } } });
  document.getElementById('modalBackdrop').click();
  APP.render();
  toast('Leave request submitted · awaiting approval', 'success');
}

function teacherClasses() {
  const t = DB.find('teachers', AUTH.current.id);
  if (!t) return [];
  return DB.get('classes').filter(c => t.classes.includes(c.id));
}

/* ---------- Dashboard ---------- */
function view_tch_dashboard() {
  const t = DB.find('teachers', AUTH.current.id);
  const classes = teacherClasses();
  const todayAttendance = DB.query('attendance', a => a.recordedBy === t.id && a.date === today());
  const totalStudents = classes.reduce((s, c) => s + COMPUTE.studentsByClass(c.id).length, 0);
  const pendingResults = DB.query('results', r => !r.approved && classes.some(c => c.id === r.classId)).length;
  const myAssignments = DB.query('assignments', a => a.teacherId === t.id);
  // Grading workload — submissions and CBTs awaiting the teacher
  const ungradedSubs = [];
  myAssignments.forEach(a => (a.submissions || []).forEach(sb => { if (sb.grade == null) ungradedSubs.push({ a, sb }); }));
  const myExams = DB.query('cbtExams', e => e.teacherId === t.id);
  const pendingCbt = DB.query('cbtSubmissions', x => x.status === 'submitted' && myExams.some(e => e.id === x.examId));
  const toGrade = ungradedSubs.length + pendingCbt.length;

  // Today's timetable
  const day = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][new Date().getDay()];
  const todaySchedule = DB.query('timetable', tt => tt.teacherId === t.id && tt.day === day).sort((a,b) => a.period - b.period);
  const subjects = DB.get('subjects');

  return `
    <div class="space-y-5">
      <div class="bg-gradient-to-br from-brand-700 to-brand-800 rounded-2xl p-5 lg:p-6 text-white">
        <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <p class="text-brand-200 text-sm">Welcome,</p>
            <h1 class="text-2xl lg:text-3xl font-extrabold">${t.name}</h1>
            <p class="text-brand-100 text-sm mt-1">${(() => {
              const subs = DB.get('subjects');
              if (Array.isArray(t.subjects) && t.subjects.length) {
                return t.subjects.map(id => (subs.find(s => s.id === id) || {}).name).filter(Boolean).join(', ');
              }
              return t.subject || 'Teacher';
            })()} · ${fdate(today(), { long: true })}</p>
          </div>
          ${renderClockInCard(t.id)}
        </div>
      </div>

      <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
        ${statCard({ label: 'My Classes', value: classes.length, icon: 'classes', color: 'brand', tooltip: `${totalStudents} students across your classes` })}
        ${statCard({ label: 'Today Marked', value: todayAttendance.length, icon: 'attendance', color: 'gold', trend: { direction: todayAttendance.length ? 'up' : 'down', label: todayAttendance.length ? 'attendance taken' : 'not marked yet' } })}
        ${statCard({ label: 'To Grade', value: toGrade, icon: 'edit', color: toGrade ? 'gold' : 'brand', trend: toGrade ? { direction: 'down', label: `${ungradedSubs.length} work · ${pendingCbt.length} CBT` } : { direction: 'up', label: 'all marked' } })}
        ${statCard({ label: 'Results Pending', value: pendingResults, icon: 'results', color: pendingResults ? 'rose' : 'brand', tooltip: 'Results you have submitted that await admin approval' })}
      </div>

      ${toGrade ? `<div class="card p-5">
        <div class="flex items-center justify-between mb-3">
          <h3 class="font-bold text-slate-900">Needs Grading</h3>
          <span class="badge badge-warn">${toGrade} item${toGrade !== 1 ? 's' : ''}</span>
        </div>
        <div class="space-y-2">
          ${ungradedSubs.slice(0, 4).map(({ a, sb }) => {
            const stu = DB.find('students', sb.studentId);
            return `<div class="flex items-center gap-3 p-2.5 bg-slate-50 rounded-xl">
              <span class="w-9 h-9 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center flex-shrink-0">${icon('results','w-5 h-5')}</span>
              <div class="flex-1 min-w-0">
                <div class="font-semibold text-sm truncate">${stu ? stu.name : 'Student'} · ${a.title}</div>
                <div class="text-xs text-slate-500">Assignment · submitted ${fdate(sb.submittedAt, { relative: true })}</div>
              </div>
              <button class="btn btn-primary !py-1.5 !px-3 text-xs" onclick="openAssignment('${a.id}')">Grade</button>
            </div>`;
          }).join('')}
          ${pendingCbt.slice(0, 4).map(sub => {
            const e = DB.find('cbtExams', sub.examId); const stu = DB.find('students', sub.studentId);
            return `<div class="flex items-center gap-3 p-2.5 bg-slate-50 rounded-xl">
              <span class="w-9 h-9 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center flex-shrink-0">${icon('classes','w-5 h-5')}</span>
              <div class="flex-1 min-w-0">
                <div class="font-semibold text-sm truncate">${stu ? stu.name : 'Student'} · ${e ? e.title : 'CBT'}</div>
                <div class="text-xs text-slate-500">CBT · theory answers to review</div>
              </div>
              <button class="btn btn-primary !py-1.5 !px-3 text-xs" onclick="reviewCbt('${sub.examId}')">Review</button>
            </div>`;
          }).join('')}
        </div>
      </div>` : ''}

      <div class="grid lg:grid-cols-2 gap-4">
        <div class="card p-5">
          <h3 class="font-bold text-slate-900 mb-3">Today's Schedule (${day})</h3>
          ${todaySchedule.length === 0 ? `<p class="text-sm text-slate-500">No classes scheduled today. Enjoy your day!</p>` : `
            <div class="space-y-2">
              ${todaySchedule.map(s => {
                const sub = subjects.find(x => x.id === s.subjectId);
                const cls = DB.find('classes', s.classId);
                return `<div class="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
                  <div class="w-12 h-12 rounded-xl bg-brand-100 text-brand-700 flex flex-col items-center justify-center">
                    <div class="text-xs font-bold">P${s.period}</div>
                  </div>
                  <div class="flex-1">
                    <div class="font-semibold text-slate-900">${sub ? sub.name : '—'}</div>
                    <div class="text-xs text-slate-500">${cls ? cls.name : ''} · ${s.time}</div>
                  </div>
                  <button class="btn btn-secondary !py-1.5 !px-2 text-xs" onclick="APP.go('tch_attendance', { classId: '${s.classId}' })">Mark Attendance</button>
                </div>`;
              }).join('')}
            </div>
          `}
        </div>

        <div class="card p-5">
          <div class="flex items-center justify-between mb-3">
            <h3 class="font-bold text-slate-900">My Assignments</h3>
            <button class="btn btn-ghost text-sm" onclick="APP.go('tch_assignments')">View all →</button>
          </div>
          ${myAssignments.slice(0,3).map(a => {
            const cls = DB.find('classes', a.classId);
            return `<div class="py-2 border-b border-slate-100 last:border-0">
              <div class="font-semibold text-sm text-slate-900">${a.title}</div>
              <div class="text-xs text-slate-500">${cls ? cls.name : ''} · Due ${fdate(a.dueDate, { short: true })}</div>
            </div>`;
          }).join('') || '<p class="text-sm text-slate-500">No assignments yet.</p>'}
          <button class="btn btn-primary w-full mt-3" onclick="createAssignmentModal()">${icon('plus','w-4 h-4')} New Assignment</button>
        </div>
      </div>

      ${renderSubstituteRequestsWidget(t.id)}
      ${renderMyLeaveWidget(t.id)}

      <div class="card p-5">
        <h3 class="font-bold text-slate-900 mb-3">My Classes</h3>
        <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          ${classes.map(c => {
            const count = COMPUTE.studentsByClass(c.id).length;
            return `<div class="p-4 border border-slate-200 rounded-xl hover:border-brand-500 cursor-pointer transition" onclick="APP.go('tch_attendance', { classId: '${c.id}' })">
              <div class="flex items-center justify-between mb-2">
                <span class="badge badge-info">${c.level}</span>
                <span class="text-xs text-slate-500">${count} students</span>
              </div>
              <h4 class="font-bold text-slate-900">${c.name}</h4>
              <div class="flex gap-1 mt-3">
                <button class="btn btn-secondary !py-1 !px-2 text-xs flex-1" onclick="event.stopPropagation(); APP.go('tch_attendance', { classId: '${c.id}' })">Attendance</button>
                <button class="btn btn-secondary !py-1 !px-2 text-xs flex-1" onclick="event.stopPropagation(); APP.go('tch_results', { classId: '${c.id}' })">Results</button>
              </div>
            </div>`;
          }).join('')}
        </div>
      </div>
    </div>
  `;
}

/* ---------- My Classes ---------- */
function view_tch_classes() {
  const classes = teacherClasses();
  return `
    ${pageHeader({ title: 'My Classes', subtitle: 'Classes you teach this term' })}
    <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
      ${classes.map(c => {
        const students = COMPUTE.studentsByClass(c.id);
        return `<div class="card p-5">
          <div class="flex items-start justify-between mb-3">
            <div>
              <span class="badge badge-info">${c.level}</span>
              <h3 class="font-bold text-lg text-slate-900 mt-2">${c.name}</h3>
              <p class="text-sm text-slate-500">${students.length} students</p>
            </div>
            <div class="w-12 h-12 rounded-xl bg-brand-100 text-brand-700 flex items-center justify-center">${icon('classes','w-6 h-6')}</div>
          </div>
          <div class="space-y-1">
            ${students.slice(0,3).map(s => `<div class="flex items-center gap-2 text-sm"><span class="avatar sm">${initials(s.name)}</span><span>${s.name}</span></div>`).join('')}
            ${students.length > 3 ? `<p class="text-xs text-slate-400">+ ${students.length - 3} more</p>` : ''}
          </div>
          <div class="grid grid-cols-2 gap-1.5 mt-3">
            <button class="btn btn-secondary !py-1.5 text-xs" onclick="APP.go('tch_attendance', { classId: '${c.id}' })">${icon('attendance','w-3 h-3')} Attendance</button>
            <button class="btn btn-secondary !py-1.5 text-xs" onclick="APP.go('tch_results', { classId: '${c.id}' })">${icon('results','w-3 h-3')} Results</button>
          </div>
        </div>`;
      }).join('')}
    </div>
  `;
}

/* ---------- Attendance ---------- */
function view_tch_attendance() {
  const classes = teacherClasses();
  if (classes.length === 0) return emptyState({ title: 'No classes assigned', body: 'Contact admin to assign you to a class.', icon: 'classes' });
  const classId = APP.params.classId || classes[0].id;
  const cls = DB.find('classes', classId);
  const students = COMPUTE.studentsByClass(classId);
  const date = APP.params.date || today();
  const existing = COMPUTE.classAttendance(classId, date);

  return `
    ${pageHeader({
      title: 'Mark Attendance',
      subtitle: `${cls.name} · ${fdate(date, { long: true })}${isOffline() ? ' · <span class="badge badge-warn ml-1">Offline</span>' : ''}`
    })}

    <div class="card p-4 mb-4 grid sm:grid-cols-2 gap-3">
      <div><label class="input-label">Class</label>
        <select class="input" onchange="APP.go('tch_attendance', { classId: this.value, date: '${date}' })">
          ${classes.map(c => `<option value="${c.id}" ${classId===c.id?'selected':''}>${c.name}</option>`).join('')}
        </select>
      </div>
      <div><label class="input-label">Date</label>
        <input type="date" class="input" value="${date}" onchange="APP.go('tch_attendance', { classId: '${classId}', date: this.value })" />
      </div>
    </div>

    <div class="card p-4 mb-4 flex items-center justify-between flex-wrap gap-2">
      <div class="text-sm text-slate-600">${existing.length}/${students.length} marked</div>
      <div class="flex gap-2">
        <button class="btn btn-ghost text-sm" onclick="bulkMarkAttendance('${classId}', '${date}', 'present')">${icon('check','w-3 h-3')} All Present</button>
        <button class="btn btn-ghost text-sm" onclick="bulkMarkAttendance('${classId}', '${date}', 'absent')">${icon('x','w-3 h-3')} All Absent</button>
        <button class="btn btn-primary text-sm" onclick="saveAttendance('${classId}', '${date}')">${icon('check','w-4 h-4')} Save & Notify</button>
      </div>
    </div>

    <div class="card overflow-hidden">
      <div class="divide-y divide-slate-100">
        ${students.map(s => {
          const cur = existing.find(e => e.studentId === s.id);
          const status = cur ? cur.status : null;
          return `<div class="p-3 flex items-center gap-3 flex-wrap" id="att_row_${s.id}">
            ${avatar(s.name, 'md')}
            <div class="flex-1 min-w-0">
              <div class="font-semibold text-slate-900">${s.name}</div>
              <div class="text-xs text-slate-500">${s.admissionNo}</div>
            </div>
            <div class="flex gap-1.5">
              <button onclick="markStudent('${s.id}', 'present')" data-stu="${s.id}" data-st="present" class="att-btn px-3 py-1.5 rounded-lg text-xs font-semibold border-2 ${status==='present'?'bg-emerald-500 text-white border-emerald-500':'bg-white border-slate-200 text-slate-600 hover:border-emerald-500'}">Present</button>
              <button onclick="markStudent('${s.id}', 'late')" data-stu="${s.id}" data-st="late" class="att-btn px-3 py-1.5 rounded-lg text-xs font-semibold border-2 ${status==='late'?'bg-amber-500 text-white border-amber-500':'bg-white border-slate-200 text-slate-600 hover:border-amber-500'}">Late</button>
              <button onclick="markStudent('${s.id}', 'absent')" data-stu="${s.id}" data-st="absent" class="att-btn px-3 py-1.5 rounded-lg text-xs font-semibold border-2 ${status==='absent'?'bg-rose-500 text-white border-rose-500':'bg-white border-slate-200 text-slate-600 hover:border-rose-500'}">Absent</button>
            </div>
          </div>`;
        }).join('')}
      </div>
    </div>
  `;
}

const _attBuffer = {};
function markStudent(studentId, status) {
  _attBuffer[studentId] = status;
  // Update button states inline (no full re-render for speed)
  const row = document.getElementById('att_row_' + studentId);
  if (row) {
    row.querySelectorAll('.att-btn').forEach(b => {
      b.className = 'att-btn px-3 py-1.5 rounded-lg text-xs font-semibold border-2 bg-white border-slate-200 text-slate-600';
      if (b.dataset.st === status) {
        const colors = { present: 'bg-emerald-500 border-emerald-500', late: 'bg-amber-500 border-amber-500', absent: 'bg-rose-500 border-rose-500' };
        b.className = 'att-btn px-3 py-1.5 rounded-lg text-xs font-semibold border-2 text-white ' + colors[status];
      }
    });
  }
}

function bulkMarkAttendance(classId, date, status) {
  const students = COMPUTE.studentsByClass(classId);
  students.forEach(s => markStudent(s.id, status));
  toast(`All marked ${status}`);
}

function saveAttendance(classId, date) {
  const students = COMPUTE.studentsByClass(classId);
  const existing = COMPUTE.classAttendance(classId, date);
  const cls = DB.find('classes', classId);
  let added = 0, absent = 0, late = 0;
  students.forEach(s => {
    const status = _attBuffer[s.id];
    if (!status) return;
    const cur = existing.find(e => e.studentId === s.id);
    const timeStamp = new Date().toTimeString().slice(0, 5); // HH:MM in 24h
    if (cur) DB.update('attendance', cur.id, { status, markedAt: timeStamp, markedAtFull: now() });
    else {
      DB.insert('attendance', { id: uid('att'), schoolId: AUTH.current.id, studentId: s.id, classId, date, status, recordedBy: AUTH.current.id, markedAt: timeStamp, markedAtFull: now() });
    }
    added++;
    // Real notification record for absent / late students (sent via WhatsApp + in-app)
    if (status === 'absent' || status === 'late') {
      const niceDate = fdate(date, { long: true });
      const stamp = new Date().toTimeString().slice(0, 5);
      const title = status === 'absent' ? 'Absence Alert' : 'Late Arrival';
      const body = status === 'absent'
        ? `${s.name} was marked absent in ${cls ? cls.name : 'class'} on ${niceDate}. Please contact the school if this is unexpected. — Bright Lights Academy`
        : `${s.name} arrived late to ${cls ? cls.name : 'class'} on ${niceDate} at ${stamp}.`;
      DB.insert('notifications', {
        id: uid('not'), userId: s.parentId,
        title, body,
        channel: 'whatsapp+app',
        type: status === 'absent' ? 'warn' : 'info',
        read: false, timestamp: now(),
        link: { view: 'par_dashboard' }
      });
      if (status === 'absent') absent++; else late++;
    }
  });
  if (added === 0) { toast('Mark at least one student first', 'warn'); return; }
  if (isOffline()) {
    for (let i = 0; i < added; i++) queueOfflineAction();
    toast(`Saved ${added} entries offline. Will sync when online.`, 'warn');
    Object.keys(_attBuffer).forEach(k => delete _attBuffer[k]);
    APP.render();
    return;
  }
  const parts = [`Saved ${added} entries`];
  if (absent) parts.push(`${absent} absence alert${absent!==1?'s':''} sent`);
  if (late) parts.push(`${late} late notice${late!==1?'s':''} sent`);
  toast(parts.join(' · '));
  Object.keys(_attBuffer).forEach(k => delete _attBuffer[k]);

  // Next-action prompt
  const t = AUTH.current;
  const classes = teacherClasses();
  const nextClass = classes.find(c => c.id !== classId);
  const hasPendingResults = DB.query('results', r => !r.approved && classes.some(c => c.id === r.classId)).length > 0;
  modal({
    title: '✓ Attendance Saved',
    body: `
      <div class="text-center py-3">
        <div class="w-14 h-14 mx-auto rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-2">${icon('check','w-7 h-7')}</div>
        <div class="text-base font-bold text-slate-900">${added} student${added!==1?'s':''} marked</div>
        ${absent ? `<div class="text-sm text-rose-700 mt-1">${absent} absent · parents notified via WhatsApp</div>` : ''}
      </div>
      <p class="text-sm text-slate-600 text-center mt-2">What's next?</p>
    `,
    footer: `
      <button class="btn btn-secondary" onclick="document.getElementById('modalBackdrop').click()">Done for now</button>
      ${nextClass ? `<button class="btn btn-secondary" onclick="document.getElementById('modalBackdrop').click(); APP.go('tch_attendance', { classId: '${nextClass.id}' })">Mark next class</button>` : ''}
      ${hasPendingResults ? `<button class="btn btn-primary" onclick="document.getElementById('modalBackdrop').click(); APP.go('tch_results')">Enter results →</button>` : `<button class="btn btn-primary" onclick="document.getElementById('modalBackdrop').click(); APP.go('tch_results')">Enter results →</button>`}
    `
  });
}

/* ---------- Results Entry ---------- */
function view_tch_results() {
  const classes = teacherClasses();
  if (classes.length === 0) return emptyState({ title: 'No classes assigned', body: 'Contact admin.', icon: 'classes' });
  const classId = APP.params.classId || classes[0].id;
  const subjectId = APP.params.subjectId || 'sub_math';
  const cls = DB.find('classes', classId);
  const subjects = DB.get('subjects');
  const students = COMPUTE.studentsByClass(classId);
  const results = DB.query('results', r => r.classId === classId && r.subjectId === subjectId);

  return `
    ${pageHeader({
      title: 'Enter Results',
      subtitle: `Enter CA1 (max 20), CA2 (max 20) and Exam (max 60) scores`
    })}
    <div class="card p-4 mb-4 grid sm:grid-cols-2 gap-3">
      <div><label class="input-label">Class</label>
        <select class="input" onchange="APP.go('tch_results', { classId: this.value, subjectId: '${subjectId}' })">
          ${classes.map(c => `<option value="${c.id}" ${classId===c.id?'selected':''}>${c.name}</option>`).join('')}
        </select>
      </div>
      <div><label class="input-label">Subject</label>
        <select class="input" onchange="APP.go('tch_results', { classId: '${classId}', subjectId: this.value })">
          ${subjects.map(s => `<option value="${s.id}" ${subjectId===s.id?'selected':''}>${s.name}</option>`).join('')}
        </select>
      </div>
    </div>

    <div class="card overflow-hidden">
      <table class="tbl">
        <thead><tr>
          <th>Student</th><th class="text-center">CA1 /20</th><th class="text-center">CA2 /20</th><th class="text-center">Exam /60</th>
          <th class="text-center">Total</th><th class="text-center">Grade</th><th>Comment</th>
        </tr></thead>
        <tbody>
          ${students.map(s => {
            const r = results.find(x => x.studentId === s.id);
            return `<tr>
              <td><div class="flex items-center gap-2">${avatar(s.name, 'sm')}<span>${s.name}</span></div></td>
              <td><input type="number" max="20" min="0" class="input !w-16 text-center" id="res_ca1_${s.id}" value="${r ? r.ca1 : ''}" oninput="recalcResult('${s.id}')" /></td>
              <td><input type="number" max="20" min="0" class="input !w-16 text-center" id="res_ca2_${s.id}" value="${r ? r.ca2 : ''}" oninput="recalcResult('${s.id}')" /></td>
              <td><input type="number" max="60" min="0" class="input !w-16 text-center" id="res_exam_${s.id}" value="${r ? r.exam : ''}" oninput="recalcResult('${s.id}')" /></td>
              <td class="text-center font-bold text-lg" id="res_total_${s.id}">${r ? r.total : '—'}</td>
              <td class="text-center" id="res_grade_${s.id}">${r ? `<span class="badge ${r.grade==='A'?'badge-success':r.grade==='F'?'badge-danger':'badge-info'}">${r.grade}</span>` : '—'}</td>
              <td>
                <div class="flex gap-1">
                  <input class="input flex-1 text-sm" id="res_cmt_${s.id}" value="${r ? r.comment : ''}" placeholder="Teacher comment…" />
                  <button class="btn btn-gold !p-1.5" title="AI suggest comment" onclick="aiSuggestComment('${s.id}', '${subjectId}')">${icon('ai','w-4 h-4')}</button>
                </div>
              </td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
      <div class="p-3 bg-slate-50 flex justify-end gap-2">
        <button class="btn btn-secondary" onclick="aiSuggestAllComments('${classId}', '${subjectId}')">${icon('ai','w-4 h-4')} AI: Suggest all comments</button>
        <button class="btn btn-primary" onclick="saveResults('${classId}', '${subjectId}')">${icon('check','w-4 h-4')} Submit for approval</button>
      </div>
    </div>
  `;
}

function recalcResult(studentId) {
  const ca1 = parseInt(document.getElementById(`res_ca1_${studentId}`).value) || 0;
  const ca2 = parseInt(document.getElementById(`res_ca2_${studentId}`).value) || 0;
  const exam = parseInt(document.getElementById(`res_exam_${studentId}`).value) || 0;
  if (ca1 > 20) document.getElementById(`res_ca1_${studentId}`).value = 20;
  if (ca2 > 20) document.getElementById(`res_ca2_${studentId}`).value = 20;
  if (exam > 60) document.getElementById(`res_exam_${studentId}`).value = 60;
  const total = ca1 + ca2 + exam;
  document.getElementById(`res_total_${studentId}`).textContent = total;
  const { grade } = COMPUTE.gradeFromScore(total);
  const cls = grade==='A'?'badge-success':grade==='F'?'badge-danger':'badge-info';
  document.getElementById(`res_grade_${studentId}`).innerHTML = `<span class="badge ${cls}">${grade}</span>`;
}

function saveResults(classId, subjectId) {
  const students = COMPUTE.studentsByClass(classId);
  let count = 0;
  students.forEach(s => {
    const ca1 = parseInt(document.getElementById(`res_ca1_${s.id}`).value) || 0;
    const ca2 = parseInt(document.getElementById(`res_ca2_${s.id}`).value) || 0;
    const exam = parseInt(document.getElementById(`res_exam_${s.id}`).value) || 0;
    const comment = document.getElementById(`res_cmt_${s.id}`).value.trim();
    if (ca1 === 0 && ca2 === 0 && exam === 0) return;
    const total = ca1 + ca2 + exam;
    const { grade } = COMPUTE.gradeFromScore(total);
    const existing = DB.query('results', r => r.studentId === s.id && r.subjectId === subjectId && r.classId === classId)[0];
    if (existing) DB.update('results', existing.id, { ca1, ca2, exam, total, grade, comment, approved: false });
    else DB.insert('results', { id: uid('res'), schoolId: AUTH.current.id, studentId: s.id, classId, subjectId, term: DB.settings().currentTerm, ca1, ca2, exam, total, grade, comment, approved: false });
    count++;
  });
  toast(`${count} result${count !== 1 ? 's' : ''} submitted for approval`);
  APP.render();
}

/* ---------- AI Report Comments ---------- */
function aiSuggestComment(studentId, subjectId) {
  const total = parseInt(document.getElementById(`res_total_${studentId}`).textContent) || 0;
  if (total === 0) { toast('Enter scores first', 'warn'); return; }
  const student = DB.find('students', studentId);
  const subject = DB.find('subjects', subjectId);
  // Mock AI: deterministic but varied comments based on score
  const banks = {
    excellent: [
      `Outstanding performance in ${subject.name}. ${student.name.split(' ')[0]} consistently demonstrates mastery and helps classmates.`,
      `An exemplary student. Their grasp of ${subject.name} concepts is remarkable. Keep aiming higher.`,
      `Brilliant work this term. ${student.name.split(' ')[0]} is a model student in ${subject.name}.`
    ],
    good: [
      `Very good showing in ${subject.name}. With more consistent practice, ${student.name.split(' ')[0]} can reach the top.`,
      `Strong understanding of ${subject.name} fundamentals. Push a little harder on the harder topics.`,
      `Solid progress this term. Continue working at this pace.`
    ],
    average: [
      `${student.name.split(' ')[0]} shows potential in ${subject.name} but needs more focus and revision.`,
      `Average performance. Please attend extra lessons and complete all assignments on time.`,
      `Capable of better. Encourage more practice exercises at home.`
    ],
    poor: [
      `${student.name.split(' ')[0]} is struggling with ${subject.name} this term. Recommend remedial classes and parental support.`,
      `Needs urgent improvement. Please discuss study habits with the class teacher.`,
      `A worrying drop in performance. We will arrange tutoring support next term.`
    ]
  };
  let key = 'average';
  if (total >= 75) key = 'excellent';
  else if (total >= 60) key = 'good';
  else if (total >= 45) key = 'average';
  else key = 'poor';
  const arr = banks[key];
  const comment = arr[Math.floor(Math.random() * arr.length)];
  // Animate typing
  const input = document.getElementById(`res_cmt_${studentId}`);
  input.value = '';
  input.placeholder = 'AI is thinking…';
  let i = 0;
  const typer = setInterval(() => {
    if (i >= comment.length) { clearInterval(typer); return; }
    input.value += comment[i++];
  }, 12);
  toast('AI comment generated. You can edit it.', 'info');
}

function aiSuggestAllComments(classId, subjectId) {
  const students = COMPUTE.studentsByClass(classId);
  toast('Generating AI comments for all students…', 'info');
  students.forEach((s, i) => {
    setTimeout(() => aiSuggestComment(s.id, subjectId), i * 250);
  });
}

/* ---------- Assignments & Learning (LMS) ---------- */
function view_tch_assignments() {
  const tab = APP.params.learnTab || 'assignments';
  return `
    ${pageHeader({
      title: 'Assignments & Learning',
      subtitle: 'Set homework, grade submissions, and share learning materials',
      actions: tab === 'materials'
        ? `<button class="btn btn-primary" onclick="createMaterialModal()">${icon('plus','w-4 h-4')} Upload Material</button>`
        : `<button class="btn btn-primary" onclick="createAssignmentModal()">${icon('plus','w-4 h-4')} New Assignment</button>`
    })}
    ${tabs([{ key: 'assignments', label: 'Assignments' }, { key: 'materials', label: 'Learning Materials' }], tab, k => { APP.params.learnTab = k; APP.render(); })}
    <div class="pt-4">${tab === 'materials' ? tch_renderMaterials() : tch_renderAssignments()}</div>
  `;
}

function tch_renderAssignments() {
  const t = AUTH.current;
  const assignments = DB.query('assignments', a => a.teacherId === t.id);
  return `
    ${assignments.length === 0 ? emptyState({ title: 'No assignments yet', body: 'Create your first assignment to share with students.', icon: 'book' }) : `
      <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        ${assignments.map(a => {
          const cls = DB.find('classes', a.classId);
          const sub = DB.find('subjects', a.subjectId);
          const classSize = COMPUTE.studentsByClass(a.classId).length;
          const submissionRate = classSize ? Math.round((a.submissions.length / classSize) * 100) : 0;
          const overdue = new Date(a.dueDate) < new Date();
          return `<div class="card card-hover p-4 cursor-pointer" onclick="openAssignment('${a.id}')">
            <div class="flex items-start justify-between gap-2 mb-2">
              <div class="flex items-center gap-1.5 flex-wrap">
                <span class="badge badge-info">${cls ? cls.name : ''}</span>
                <span class="badge badge-neutral">${sub ? sub.name : ''}</span>
              </div>
              <button class="btn btn-ghost !p-1" onclick="event.stopPropagation(); editAssignmentModal('${a.id}')" title="Edit">${icon('edit', 'w-4 h-4')}</button>
            </div>
            <h3 class="font-bold text-slate-900 mb-1">${a.title}</h3>
            <p class="text-sm text-slate-500 line-clamp-2 mb-3">${a.description}</p>
            <div class="space-y-2">
              <div class="flex justify-between text-xs">
                <span class="text-slate-500">Submissions</span>
                <span class="font-semibold">${a.submissions.length}/${classSize}</span>
              </div>
              <div class="progress"><div class="progress-bar" style="width: ${submissionRate}%"></div></div>
              <div class="flex justify-between text-xs pt-1">
                <span class="text-slate-500">Due ${fdate(a.dueDate, { short: true })}</span>
                ${overdue ? '<span class="badge badge-danger">Overdue</span>' : '<span class="badge badge-success">Active</span>'}
              </div>
            </div>
          </div>`;
        }).join('')}
      </div>
    `}
  `;
}

/* ---------- LMS: Learning Materials ---------- */
function tch_renderMaterials() {
  const t = AUTH.current;
  const materials = DB.query('learningMaterials', m => m.teacherId === t.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return `
    <div class="bg-blue-50 border border-blue-200 rounded-xl p-3 text-sm text-blue-900 mb-4">
      ${icon('info','w-4 h-4 inline mr-1')} Notes and videos you upload here appear instantly on your students' <strong>Learning</strong> portal.
    </div>
    ${materials.length === 0 ? emptyState({ title: 'No materials yet', body: 'Upload notes or share a video link for your students.', icon: 'book' }) : `
      <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        ${materials.map(m => {
          const cls = DB.find('classes', m.classId);
          return `<div class="card p-4">
            <div class="flex items-start justify-between gap-2 mb-2">
              <div class="flex items-center gap-1.5 flex-wrap">
                <span class="badge ${m.type === 'video' ? 'badge-danger' : 'badge-info'}">${m.type === 'video' ? 'Video' : 'Note'}</span>
                <span class="badge badge-neutral">${cls ? cls.name : ''}</span>
              </div>
              <button class="btn btn-ghost !p-1 text-rose-600" title="Delete" onclick="deleteMaterial('${m.id}')">${icon('trash','w-4 h-4')}</button>
            </div>
            <h3 class="font-bold text-slate-900 text-sm mb-1">${m.title}</h3>
            <p class="text-xs text-slate-500 line-clamp-2 mb-2">${m.description || ''}</p>
            <div class="text-xs text-slate-400">${DB.find('subjects', m.subjectId) ? DB.find('subjects', m.subjectId).name : ''} · ${fdate(m.createdAt, { short: true })}</div>
          </div>`;
        }).join('')}
      </div>
    `}
  `;
}

let _materialFile = null;
function onMaterialFile(ev) {
  _materialFile = null;
  const file = ev.target.files[0];
  if (!file) return;
  if (file.size > 3 * 1024 * 1024) { toast('File too large (max 3MB)', 'danger'); return; }
  const reader = new FileReader();
  reader.onload = e => {
    _materialFile = { name: file.name, type: file.type, size: Math.round(file.size / 1024) + ' KB', data: e.target.result };
    const p = document.getElementById('mat_preview');
    if (p) p.innerHTML = `<div class="flex items-center gap-2 p-2 bg-emerald-50 border border-emerald-200 rounded-lg text-sm">${icon('paperclip','w-4 h-4 text-emerald-600')}<span class="flex-1 truncate font-semibold text-emerald-900">${file.name}</span><span class="text-xs text-emerald-700">${_materialFile.size}</span></div>`;
  };
  reader.readAsDataURL(file);
}

function createMaterialModal() {
  _materialFile = null;
  const classes = teacherClasses();
  const subjects = DB.get('subjects');
  modal({
    title: 'Upload Learning Material',
    body: `
      <div class="space-y-3">
        <div><label class="input-label">Title</label><input id="mat_title" class="input" placeholder="e.g. Photosynthesis — Class Notes" /></div>
        <div class="grid grid-cols-2 gap-3">
          <div><label class="input-label">Class</label><select id="mat_class" class="input">${classes.map(c => `<option value="${c.id}">${c.name}</option>`).join('')}</select></div>
          <div><label class="input-label">Subject</label><select id="mat_subject" class="input">${subjects.map(s => `<option value="${s.id}">${s.name}</option>`).join('')}</select></div>
        </div>
        <div><label class="input-label">Type</label>
          <select id="mat_type" class="input" onchange="document.getElementById('mat_urlRow').classList.toggle('hidden', this.value!=='video')">
            <option value="note">Note / Document</option>
            <option value="video">Video (link)</option>
          </select>
        </div>
        <div id="mat_urlRow" class="hidden"><label class="input-label">Video URL (YouTube, etc.)</label><input id="mat_url" class="input" placeholder="https://…" /></div>
        <div><label class="input-label">Description</label><textarea id="mat_desc" rows="3" class="input" placeholder="What is this material about?"></textarea></div>
        <div>
          <label class="input-label">Attach file (optional — PDF / Word / image, max 3MB)</label>
          <input type="file" id="mat_file" class="hidden" accept="application/pdf,.doc,.docx,image/*" onchange="onMaterialFile(event)" />
          <div class="border-2 border-dashed border-slate-300 rounded-xl p-3 text-center hover:border-brand-400 cursor-pointer" onclick="document.getElementById('mat_file').click()">
            ${icon('upload','w-5 h-5 mx-auto text-slate-400 mb-1')}<div class="text-xs text-slate-500">Click to attach a file</div>
          </div>
          <div id="mat_preview" class="mt-2"></div>
        </div>
      </div>
    `,
    footer: `<button class="btn btn-secondary" onclick="document.getElementById('modalBackdrop').click()">Cancel</button>
             <button class="btn btn-primary" onclick="saveMaterial()">${icon('check','w-4 h-4')} Publish to Students</button>`
  });
}

function saveMaterial() {
  const title = document.getElementById('mat_title').value.trim();
  if (!title) { toast('Title is required', 'danger'); return; }
  const classId = document.getElementById('mat_class').value;
  const type = document.getElementById('mat_type').value;
  const url = document.getElementById('mat_url') ? document.getElementById('mat_url').value.trim() : '';
  const m = {
    id: uid('lm'), schoolId: AUTH.current.schoolId || 'sch_brightlights',
    classId, subjectId: document.getElementById('mat_subject').value, teacherId: AUTH.current.id,
    title, type, description: document.getElementById('mat_desc').value.trim(),
    url, file: _materialFile || null, createdAt: now()
  };
  DB.insert('learningMaterials', m);
  // Notify students in the class
  COMPUTE.studentsByClass(classId).forEach(s => {
    DB.insert('notifications', { id: uid('not'), userId: s.id, title: 'New Learning Material', body: `${title} (${DB.find('subjects', m.subjectId) ? DB.find('subjects', m.subjectId).name : ''})`, type: 'info', read: false, timestamp: now(), link: { view: 'stu_learning' } });
  });
  _materialFile = null;
  document.getElementById('modalBackdrop').click();
  APP.render();
  toast('Material published to students', 'success');
}

function deleteMaterial(id) {
  const m = DB.find('learningMaterials', id);
  confirm(`Delete "${m.title}"? Students will no longer see it.`, () => {
    DB.remove('learningMaterials', id);
    APP.render();
    toast('Material deleted', 'info');
  }, { yesLabel: 'Delete', danger: true });
}

/* ---------- Assignment detail / management ---------- */
function openAssignment(assignmentId) {
  const a = DB.find('assignments', assignmentId);
  if (!a) return;
  const cls = DB.find('classes', a.classId);
  const sub = DB.find('subjects', a.subjectId);
  const students = COMPUTE.studentsByClass(a.classId);
  const submissionsMap = {};
  a.submissions.forEach(sub => { submissionsMap[sub.studentId] = sub; });

  modal({
    title: a.title,
    size: 'lg',
    body: `
      <div class="space-y-4">
        <div class="flex items-center gap-2 flex-wrap">
          <span class="badge badge-info">${cls ? cls.name : ''}</span>
          <span class="badge badge-neutral">${sub ? sub.name : ''}</span>
          <span class="badge ${new Date(a.dueDate) < new Date() ? 'badge-danger' : 'badge-success'}">Due ${fdate(a.dueDate, { long: true })}</span>
        </div>

        <div>
          <h4 class="text-xs font-semibold uppercase text-slate-500 mb-1">Instructions</h4>
          <div class="bg-slate-50 rounded-xl p-3 text-sm text-slate-700 whitespace-pre-wrap">${a.description}</div>
        </div>

        <div>
          <div class="flex items-center justify-between mb-2">
            <h4 class="text-xs font-semibold uppercase text-slate-500">Submissions (${a.submissions.length}/${students.length})</h4>
          </div>
          <div class="space-y-2 max-h-96 overflow-y-auto scroll-area">
            ${students.map(s => {
              const sub = submissionsMap[s.id];
              const graded = sub && sub.grade != null;
              return `<div class="p-3 bg-slate-50 rounded-xl">
                <div class="flex items-center gap-3">
                  ${avatar(s.name, 'sm')}
                  <div class="flex-1 min-w-0">
                    <div class="font-semibold text-sm">${s.name}</div>
                    <div class="text-xs text-slate-500">${sub ? 'Submitted ' + fdate(sub.submittedAt, { relative: true }) : 'Not submitted'}</div>
                  </div>
                  ${sub ? (graded ? `<span class="badge badge-success">${sub.grade}/100</span>` : `<span class="badge badge-warn">To grade</span>`) : `<span class="badge badge-neutral">Pending</span>`}
                </div>
                ${sub && (sub.text || sub.file) ? `<div class="mt-2 pl-11 space-y-1">
                  ${sub.text ? `<div class="text-sm text-slate-700 bg-white rounded-lg p-2 border border-slate-200">${sub.text}</div>` : ''}
                  ${sub.file ? `<a href="${sub.file.data}" download="${sub.file.name}" class="inline-flex items-center gap-1.5 text-xs text-brand-700 font-semibold">${icon('paperclip','w-3.5 h-3.5')} ${sub.file.name}</a>` : ''}
                </div>` : ''}
                ${sub && !graded ? `<div class="mt-2 pl-11 flex items-center gap-2 flex-wrap">
                  <input type="number" min="0" max="100" placeholder="/100" class="input !w-20 text-sm" id="grd_${s.id}" />
                  <input type="text" placeholder="Feedback (optional)" class="input !w-48 text-sm flex-1" id="fb_${s.id}" />
                  <button class="btn btn-primary !py-1.5 !px-3 text-xs" onclick="gradeSubmission('${a.id}', '${s.id}')">${icon('check','w-3.5 h-3.5')} Grade</button>
                </div>` : ''}
                ${graded && sub.feedback ? `<div class="mt-2 pl-11 text-xs text-emerald-700"><strong>Your feedback:</strong> ${sub.feedback}</div>` : ''}
              </div>`;
            }).join('')}
          </div>
        </div>
      </div>
    `,
    footer: `
      <button class="btn btn-danger" onclick="deleteAssignmentConfirm('${a.id}')">${icon('trash','w-4 h-4')} Delete</button>
      <button class="btn btn-secondary" onclick="document.getElementById('modalBackdrop').click()">Close</button>
      <button class="btn btn-primary" onclick="editAssignmentModal('${a.id}')">${icon('edit','w-4 h-4')} Edit</button>
    `
  });
}

function gradeSubmission(assignmentId, studentId) {
  const a = DB.find('assignments', assignmentId);
  const input = document.getElementById('grd_' + studentId);
  const grade = parseInt(input.value);
  if (isNaN(grade) || grade < 0 || grade > 100) { toast('Enter a grade 0–100', 'danger'); return; }
  const fbEl = document.getElementById('fb_' + studentId);
  const feedback = fbEl ? fbEl.value.trim() : '';
  const idx = a.submissions.findIndex(s => s.studentId === studentId);
  if (idx === -1) return;
  a.submissions[idx].grade = grade;
  a.submissions[idx].feedback = feedback;
  a.submissions[idx].gradedAt = now();
  DB.update('assignments', assignmentId, { submissions: a.submissions });
  const student = DB.find('students', studentId);
  // Notify the student directly
  if (student) DB.insert('notifications', { id: uid('not'), userId: student.id, title: 'Assignment Graded', body: `${a.title}: ${grade}/100${feedback ? ' — ' + feedback : ''}`, type: 'success', read: false, timestamp: now(), link: { view: 'stu_assignments' } });
  // And keep the parent informed
  if (student) DB.insert('notifications', { id: uid('not'), userId: student.parentId, title: 'Assignment Graded', body: `${student.name}: ${a.title} — ${grade}/100`, type: 'info', read: false, timestamp: now(), link: { view: 'par_dashboard' } });
  toast(`${student ? student.name : 'Student'} graded ${grade}/100`);
  openAssignment(assignmentId);
}

function deleteAssignmentConfirm(assignmentId) {
  const a = DB.find('assignments', assignmentId);
  confirm(`Delete "${a.title}"? This cannot be undone. Any submissions will also be removed.`, () => {
    DB.remove('assignments', assignmentId);
    document.getElementById('modalBackdrop').click();
    APP.render();
    toast('Assignment deleted', 'info');
  }, { yesLabel: 'Delete', danger: true });
}

function editAssignmentModal(assignmentId) {
  // Close any existing modal first
  const root = document.getElementById('modalBackdrop'); if (root) root.click();
  createAssignmentModal(assignmentId);
}

function createAssignmentModal(editingId) {
  const classes = teacherClasses();
  const subjects = DB.get('subjects');
  const existing = editingId ? DB.find('assignments', editingId) : null;
  const isEdit = !!existing;

  modal({
    title: isEdit ? 'Edit Assignment' : 'Create Assignment',
    body: `
      <div class="space-y-3">
        <div><label class="input-label">Title</label><input id="as_title" class="input" placeholder="e.g. Algebra Practice Set 4" value="${existing ? existing.title.replace(/"/g, '&quot;') : ''}" /></div>
        <div class="grid grid-cols-2 gap-3">
          <div><label class="input-label">Class</label>
            <select id="as_class" class="input">${classes.map(c => `<option value="${c.id}" ${existing && existing.classId === c.id ? 'selected' : ''}>${c.name}</option>`).join('')}</select>
          </div>
          <div><label class="input-label">Subject</label>
            <select id="as_subject" class="input">${subjects.map(s => `<option value="${s.id}" ${existing && existing.subjectId === s.id ? 'selected' : ''}>${s.name}</option>`).join('')}</select>
          </div>
        </div>
        <div><label class="input-label">Description / Instructions</label><textarea id="as_desc" rows="4" class="input" placeholder="What students need to do…">${existing ? existing.description : ''}</textarea></div>
        <div><label class="input-label">Due Date</label><input id="as_due" type="date" class="input" value="${existing ? existing.dueDate : daysAhead(7)}" /></div>
        <div class="border-2 border-dashed border-slate-200 rounded-xl p-3 text-center text-sm text-slate-500">
          ${icon('paperclip','w-4 h-4 inline mr-1')} Attach files (simulated)
        </div>
      </div>
    `,
    footer: `<button class="btn btn-secondary" onclick="document.getElementById('modalBackdrop').click()">Cancel</button>
             <button class="btn btn-primary" onclick="saveAssignment(${isEdit ? "'" + editingId + "'" : 'null'})">${isEdit ? icon('check','w-4 h-4') + ' Save Changes' : 'Post Assignment'}</button>`
  });
}

function saveAssignment(editingId) {
  const title = document.getElementById('as_title').value.trim();
  const classId = document.getElementById('as_class').value;
  const subjectId = document.getElementById('as_subject').value;
  const description = document.getElementById('as_desc').value.trim();
  const dueDate = document.getElementById('as_due').value;
  if (!title || !description) { toast('Title and description required', 'danger'); return; }

  if (editingId) {
    DB.update('assignments', editingId, { title, classId, subjectId, description, dueDate, updatedAt: now() });
    document.getElementById('modalBackdrop').click();
    APP.render();
    toast('Assignment updated');
    return;
  }

  DB.insert('assignments', {
    id: uid('asn'), schoolId: AUTH.current.id, classId, subjectId, teacherId: AUTH.current.id,
    title, description, dueDate, createdAt: now(), submissions: []
  });
  // Notify all parents in the class
  const parents = COMPUTE.studentsByClass(classId).map(s => s.parentId);
  [...new Set(parents)].forEach(pid => {
    DB.insert('notifications', { id: uid('not'), userId: pid, title: 'New Assignment', body: `${title} — due ${fdate(dueDate, { short: true })}`, type: 'info', read: false, timestamp: now(), link: { view: 'par_dashboard' } });
  });
  document.getElementById('modalBackdrop').click();
  APP.render();
  toast(`Assignment posted. ${parents.length} parents notified.`);
}

/* ---------- Lesson Plans ---------- */
function view_tch_lessons() {
  const lessons = DB.query('lessonPlans', l => l.teacherId === AUTH.current.id);
  const subjects = DB.get('subjects');
  return `
    ${pageHeader({
      title: 'Lesson Plans',
      subtitle: 'Weekly schemes and lesson notes',
      actions: `<button class="btn btn-primary" onclick="createLessonModal()">${icon('plus','w-4 h-4')} New Lesson Plan</button>`
    })}
    ${lessons.length === 0 ? emptyState({ title: 'No lesson plans yet', body: 'Document your weekly plans here.', icon: 'book' }) : `
      <div class="space-y-3">
        ${lessons.map(l => {
          const cls = DB.find('classes', l.classId);
          const sub = subjects.find(s => s.id === l.subjectId);
          return `<div class="card p-4">
            <div class="flex items-center justify-between mb-2">
              <div class="flex items-center gap-2">
                <span class="badge badge-info">${cls ? cls.name : ''}</span>
                <span class="badge badge-neutral">${sub ? sub.name : ''}</span>
                <span class="badge badge-success">${l.week}</span>
              </div>
              <span class="text-xs text-slate-400">${fdate(l.createdAt, { short: true })}</span>
            </div>
            <h3 class="font-bold text-slate-900">${l.topic}</h3>
            <div class="grid sm:grid-cols-3 gap-3 mt-3 text-sm">
              <div><div class="text-xs uppercase font-semibold text-slate-500 mb-1">Objectives</div><div>${l.objectives}</div></div>
              <div><div class="text-xs uppercase font-semibold text-slate-500 mb-1">Activities</div><div>${l.activities}</div></div>
              <div><div class="text-xs uppercase font-semibold text-slate-500 mb-1">Resources</div><div>${l.resources}</div></div>
            </div>
            ${l.file ? `<a href="${l.file.data}" download="${l.file.name}" class="mt-3 inline-flex items-center gap-2 px-3 py-1.5 bg-emerald-50 border border-emerald-200 rounded-lg text-sm hover:bg-emerald-100">
              ${icon('paperclip','w-4 h-4 text-emerald-600')}
              <span class="font-semibold text-emerald-900">${l.file.name}</span>
              <span class="text-xs text-emerald-700">${l.file.size}</span>
              ${icon('download','w-3.5 h-3.5 text-emerald-700')}
            </a>` : ''}
          </div>`;
        }).join('')}
      </div>
    `}
  `;
}

let _lessonFileBuffer = null;
function onLessonFilePick(ev) {
  const file = ev.target.files[0];
  if (!file) return;
  if (file.size > 2 * 1024 * 1024) { toast('File too large (max 2MB)', 'danger'); return; }
  const reader = new FileReader();
  reader.onload = e => {
    _lessonFileBuffer = { name: file.name, type: file.type, size: Math.round(file.size / 1024) + ' KB', data: e.target.result, uploadedAt: now() };
    const preview = document.getElementById('lp_filePreview');
    if (preview) preview.innerHTML = `<div class="flex items-center gap-2 p-2 bg-emerald-50 border border-emerald-200 rounded-lg text-sm">${icon('paperclip','w-4 h-4 text-emerald-600')}<span class="flex-1 truncate font-semibold text-emerald-900">${file.name}</span><span class="text-xs text-emerald-700">${_lessonFileBuffer.size}</span><button class="text-rose-600 text-xs" onclick="_lessonFileBuffer=null; document.getElementById('lp_filePreview').innerHTML=''">Remove</button></div>`;
  };
  reader.readAsDataURL(file);
}

function createLessonModal() {
  _lessonFileBuffer = null;
  const classes = teacherClasses();
  const subjects = DB.get('subjects');
  modal({
    title: 'New Lesson Plan',
    body: `
      <div class="space-y-3">
        <div class="grid grid-cols-2 gap-3">
          <div><label class="input-label">Class</label>
            <select id="lp_class" class="input" onchange="refreshLessonSchemes()">${classes.map(c => `<option value="${c.id}">${c.name}</option>`).join('')}</select>
          </div>
          <div><label class="input-label">Subject</label>
            <select id="lp_subject" class="input" onchange="refreshLessonSchemes()">${subjects.map(s => `<option value="${s.id}">${s.name}</option>`).join('')}</select>
          </div>
        </div>
        <div id="lp_schemeRow">
          <label class="input-label">Tie to Scheme of Work (auto-fills week + topic)</label>
          <select id="lp_scheme" class="input" onchange="onLessonSchemeChange()">
            <option value="">— None (manual entry) —</option>
          </select>
        </div>
        <div class="grid grid-cols-2 gap-3">
          <div><label class="input-label">Week</label><input id="lp_week" class="input" placeholder="e.g. Week 7" /></div>
          <div><label class="input-label">Topic</label><input id="lp_topic" class="input" placeholder="e.g. Quadratic Equations" /></div>
        </div>
        <div><label class="input-label">Objectives</label><textarea id="lp_obj" rows="2" class="input"></textarea></div>
        <div><label class="input-label">Activities</label><textarea id="lp_act" rows="2" class="input"></textarea></div>
        <div><label class="input-label">Resources / Materials</label><input id="lp_res" class="input" /></div>
        <div>
          <label class="input-label">Attach Lesson Plan File (PDF / Word / Image — optional)</label>
          <input type="file" id="lp_fileInput" accept="application/pdf,.doc,.docx,image/*" class="hidden" onchange="onLessonFilePick(event)" />
          <div class="border-2 border-dashed border-slate-300 rounded-xl p-3 text-center hover:border-brand-400 cursor-pointer" onclick="document.getElementById('lp_fileInput').click()">
            ${icon('upload','w-5 h-5 mx-auto text-slate-400 mb-1')}
            <div class="text-xs text-slate-500">Click to upload — your prepared lesson plan</div>
          </div>
          <div id="lp_filePreview" class="mt-2"></div>
        </div>
      </div>
    `,
    footer: `<button class="btn btn-secondary" onclick="document.getElementById('modalBackdrop').click()">Cancel</button>
             <button class="btn btn-primary" onclick="saveLesson()">Save Plan</button>`
  });
}

function refreshLessonSchemes() {
  const classId = (document.getElementById('lp_class') || {}).value;
  const subjectId = (document.getElementById('lp_subject') || {}).value;
  const select = document.getElementById('lp_scheme');
  if (!select || !classId || !subjectId) return;
  const schoolId = AUTH.current.schoolId || AUTH.current.id;
  const scheme = DB.query('schemesOfWork', s => s.schoolId === schoolId && s.classId === classId && s.subjectId === subjectId)[0];
  if (!scheme) {
    select.innerHTML = '<option value="">— No scheme of work for this class/subject —</option>';
    return;
  }
  select.innerHTML = '<option value="">— None (manual entry) —</option>' +
    scheme.weeks.map((w, idx) => `<option value="${scheme.id}|${idx}" ${w.covered ? 'data-covered="1"' : ''}>Week ${w.week}: ${w.topic}${w.covered ? ' ✓' : ''}</option>`).join('');
}

function onLessonSchemeChange() {
  const val = document.getElementById('lp_scheme').value;
  if (!val) return;
  const [schemeId, idx] = val.split('|');
  const scheme = DB.find('schemesOfWork', schemeId);
  if (!scheme) return;
  const w = scheme.weeks[parseInt(idx)];
  document.getElementById('lp_week').value = 'Week ' + w.week;
  document.getElementById('lp_topic').value = w.topic;
  document.getElementById('lp_obj').value = w.objectives || '';
  document.getElementById('lp_res').value = w.resources || '';
}

function saveLesson() {
  const schemeRef = (document.getElementById('lp_scheme') || {}).value;
  const lp = {
    id: uid('lp'), schoolId: AUTH.current.schoolId || AUTH.current.id, teacherId: AUTH.current.id,
    classId: document.getElementById('lp_class').value,
    subjectId: document.getElementById('lp_subject').value,
    week: document.getElementById('lp_week').value.trim(),
    topic: document.getElementById('lp_topic').value.trim(),
    objectives: document.getElementById('lp_obj').value.trim(),
    activities: document.getElementById('lp_act').value.trim(),
    resources: document.getElementById('lp_res').value.trim(),
    file: _lessonFileBuffer,
    schemeRef: schemeRef || null,
    createdAt: now()
  };
  if (!lp.topic || !lp.week) { toast('Week and topic required', 'danger'); return; }
  DB.insert('lessonPlans', lp);

  // If tied to a scheme, mark that week as covered automatically
  if (schemeRef) {
    const [schemeId, idx] = schemeRef.split('|');
    const scheme = DB.find('schemesOfWork', schemeId);
    if (scheme && !scheme.weeks[parseInt(idx)].covered) {
      scheme.weeks[parseInt(idx)].covered = true;
      scheme.weeks[parseInt(idx)].coveredAt = now();
      scheme.weeks[parseInt(idx)].coveredBy = AUTH.current.id;
      DB.update('schemesOfWork', schemeId, { weeks: scheme.weeks });
    }
  }

  _lessonFileBuffer = null;
  document.getElementById('modalBackdrop').click();
  APP.render();
  toast('Lesson plan saved' + (schemeRef ? ' · scheme week marked covered' : '') + (lp.file ? ' · attachment uploaded' : ''));
}

// Wire scheme dropdown when modal opens
setTimeout(() => {
  // overridden later when the modal actually opens; refreshLessonSchemes is called on class/subject change
}, 0);

/* ---------- My Timetable ---------- */
function view_tch_timetable() {
  const view = APP.params.ttScope || 'week';
  return `
    ${pageHeader({ title: 'My Schedule', subtitle: 'Your classes for the day, week, or month' })}
    <div class="flex gap-2 mb-4">
      <button class="chip ${view==='day'?'active':''}" onclick="APP.params.ttScope='day'; APP.render()">Today</button>
      <button class="chip ${view==='week'?'active':''}" onclick="APP.params.ttScope='week'; APP.render()">This Week</button>
      <button class="chip ${view==='month'?'active':''}" onclick="APP.params.ttScope='month'; APP.render()">This Month</button>
    </div>
    <div>
      ${view === 'day' ? renderTeacherDayView() : view === 'month' ? renderTeacherMonthView() : renderTeacherWeekView()}
    </div>
  `;
}

function renderTeacherWeekView() {
  const t = AUTH.current;
  const tt = DB.query('timetable', x => x.teacherId === t.id);
  const subjects = DB.get('subjects');
  const days = ['Monday','Tuesday','Wednesday','Thursday','Friday'];
  const periods = [1,2,3,4,5,6,7,8];
  return `
    <div class="card overflow-hidden">
      <div class="overflow-x-auto">
        <table class="tbl">
          <thead><tr><th>Period</th>${days.map(d => `<th>${d}</th>`).join('')}</tr></thead>
          <tbody>
            ${periods.map(p => {
              const entries = days.map(d => tt.find(x => x.day === d && x.period === p));
              if (entries.every(e => !e)) return '';
              return `<tr>
                <td><strong>P${p}</strong><br><span class="text-xs text-slate-500">${entries.find(Boolean) ? entries.find(Boolean).time : ''}</span></td>
                ${entries.map(e => {
                  if (!e) return '<td class="text-slate-300">—</td>';
                  const sub = subjects.find(s => s.id === e.subjectId);
                  const cls = DB.find('classes', e.classId);
                  return `<td><div class="font-semibold">${sub ? sub.name : ''}</div><div class="text-xs text-slate-500">${cls ? cls.name : ''}</div></td>`;
                }).join('')}
              </tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function renderTeacherDayView() {
  const t = AUTH.current;
  const dayName = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][new Date().getDay()];
  const todays = DB.query('timetable', x => x.teacherId === t.id && x.day === dayName).sort((a, b) => a.period - b.period);
  const subjects = DB.get('subjects');
  if (todays.length === 0) {
    return emptyState({ title: 'No classes today', body: dayName + ' is free for you. Use the time for grading or lesson prep.', icon: 'calendar' });
  }
  return `
    <div class="card p-5">
      <h3 class="font-bold text-slate-900 mb-3">${dayName}, ${fdate(today(), { long: true })}</h3>
      <div class="space-y-2">
        ${todays.map(e => {
          const sub = subjects.find(s => s.id === e.subjectId);
          const cls = DB.find('classes', e.classId);
          const studentCount = cls ? COMPUTE.studentsByClass(cls.id).length : 0;
          return `<div class="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
            <div class="w-14 h-14 rounded-xl bg-brand-100 text-brand-700 flex flex-col items-center justify-center flex-shrink-0">
              <div class="text-xs font-bold">P${e.period}</div>
              <div class="text-xs">${e.time.split('-')[0]}</div>
            </div>
            <div class="flex-1 min-w-0">
              <div class="font-bold text-slate-900">${sub ? sub.name : '—'}</div>
              <div class="text-sm text-slate-500">${cls ? cls.name : ''} · ${studentCount} students · ${e.time}</div>
            </div>
            <button class="btn btn-secondary !py-1.5 text-xs" onclick="APP.go('tch_attendance', { classId: '${e.classId}' })">${icon('attendance','w-3.5 h-3.5')} Attendance</button>
          </div>`;
        }).join('')}
      </div>
    </div>
  `;
}

function renderTeacherMonthView() {
  const t = AUTH.current;
  const tt = DB.query('timetable', x => x.teacherId === t.id);
  const subjects = DB.get('subjects');
  // Count classes per day in the month
  const now_ = new Date();
  const year = now_.getFullYear();
  const month = now_.getMonth();
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const dayNames = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  // Build cells
  const cells = [];
  for (let i = 0; i < firstDay; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) {
    const dayDate = new Date(year, month, d);
    const dayName = dayNames[dayDate.getDay()];
    const periodsThisDay = tt.filter(p => p.day === dayName);
    cells.push({ day: d, dayName, periods: periodsThisDay, isWeekend: dayDate.getDay() === 0 || dayDate.getDay() === 6, isToday: d === now_.getDate() });
  }
  const totalThisMonth = cells.filter(Boolean).reduce((s, c) => s + (c.isWeekend ? 0 : c.periods.length), 0);

  return `
    <div class="card p-5">
      <div class="flex items-center justify-between mb-3">
        <h3 class="font-bold text-slate-900">${now_.toLocaleString('en-GB', { month: 'long', year: 'numeric' })}</h3>
        <span class="text-sm text-slate-500"><strong>${totalThisMonth}</strong> classes scheduled this month</span>
      </div>
      <div class="grid grid-cols-7 gap-1 mb-2 text-xs font-semibold text-slate-500 text-center">
        ${['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d => `<div class="py-1">${d}</div>`).join('')}
      </div>
      <div class="grid grid-cols-7 gap-1">
        ${cells.map(c => {
          if (!c) return '<div></div>';
          const count = c.isWeekend ? 0 : c.periods.length;
          return `<div class="min-h-[64px] p-1.5 rounded-lg ${c.isToday ? 'bg-brand-100 border-2 border-brand-500' : c.isWeekend ? 'bg-slate-50' : 'bg-white border border-slate-200'}">
            <div class="text-xs font-bold ${c.isToday ? 'text-brand-700' : 'text-slate-700'}">${c.day}</div>
            ${count > 0 ? `<div class="text-xs mt-1 text-brand-700 font-semibold">${count} class${count !== 1 ? 'es' : ''}</div>` : ''}
            ${count > 0 ? c.periods.slice(0, 2).map(p => {
              const sub = subjects.find(s => s.id === p.subjectId);
              return `<div class="text-xs text-slate-600 truncate">${sub ? sub.name.split(' ')[0] : ''}</div>`;
            }).join('') : ''}
          </div>`;
        }).join('')}
      </div>
    </div>
  `;
}

/* ---------- Messages ---------- */
function view_tch_messages() { return view_messages_shared('teacher'); }

/* ============================================================
   CBT — Teacher authoring & review
   ============================================================ */
function view_tch_cbt() {
  const t = AUTH.current;
  const exams = DB.query('cbtExams', e => e.teacherId === t.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return `
    ${pageHeader({
      title: 'CBT Exams',
      subtitle: 'Create computer-based tests and review submissions',
      actions: `<button class="btn btn-primary" onclick="createCbtExamModal()">${icon('plus','w-4 h-4')} New CBT</button>`
    })}
    ${exams.length === 0 ? emptyState({ title: 'No CBT exams yet', body: 'Create your first computer-based test for your class.', icon: 'classes' }) : `
      <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        ${exams.map(e => {
          const cls = DB.find('classes', e.classId);
          const subs = DB.query('cbtSubmissions', x => x.examId === e.id);
          const pending = subs.filter(x => x.status === 'submitted').length;
          const classSize = COMPUTE.studentsByClass(e.classId).length;
          return `<div class="card p-4">
            <div class="flex items-center gap-1.5 flex-wrap mb-2">
              <span class="badge badge-info">${cls ? cls.name : ''}</span>
              <span class="badge badge-neutral">${DB.find('subjects', e.subjectId) ? DB.find('subjects', e.subjectId).name : ''}</span>
              <span class="badge ${e.status === 'published' ? 'badge-success' : 'badge-warn'}">${e.status}</span>
            </div>
            <h3 class="font-bold text-slate-900 mb-1">${e.title}</h3>
            <div class="text-xs text-slate-500 mb-3">${e.questions.length} questions · ${e.durationMins} min · Due ${fdate(e.dueDate, { short: true })}</div>
            <div class="flex items-center justify-between text-xs mb-3">
              <span class="text-slate-500">Submissions</span>
              <span class="font-semibold">${subs.length}/${classSize}</span>
            </div>
            ${pending ? `<div class="text-xs text-amber-700 mb-2">⚠ ${pending} need theory review</div>` : ''}
            <button class="btn btn-secondary w-full text-sm" onclick="reviewCbt('${e.id}')">${icon('reports','w-4 h-4')} Review Submissions</button>
          </div>`;
        }).join('')}
      </div>
    `}
  `;
}

let _cbtDraft = null;
function createCbtExamModal() {
  _cbtDraft = { questions: [], title: '', classId: '', subjectId: '', duration: 20, rules: 'Answer all questions.' };
  renderCbtBuilder();
}

function _captureCbtMeta() {
  if (document.getElementById('cbt_title')) {
    _cbtDraft.title = document.getElementById('cbt_title').value;
    _cbtDraft.classId = document.getElementById('cbt_class').value;
    _cbtDraft.subjectId = document.getElementById('cbt_subject').value;
    _cbtDraft.duration = document.getElementById('cbt_duration').value;
    _cbtDraft.rules = document.getElementById('cbt_rules').value;
  }
}

function renderCbtBuilder() {
  const classes = teacherClasses();
  const subjects = DB.get('subjects');
  const d = _cbtDraft;
  modal({
    title: 'Create CBT Exam',
    size: 'lg',
    body: `
      <div class="space-y-4">
        <div><label class="input-label">Exam Title</label><input id="cbt_title" class="input" value="${(d.title || '').replace(/"/g,'&quot;')}" placeholder="e.g. Mathematics Mid-Term CBT" /></div>
        <div class="grid grid-cols-2 gap-3">
          <div><label class="input-label">Class</label><select id="cbt_class" class="input">${classes.map(c => `<option value="${c.id}" ${d.classId === c.id ? 'selected' : ''}>${c.name}</option>`).join('')}</select></div>
          <div><label class="input-label">Subject</label><select id="cbt_subject" class="input">${subjects.map(s => `<option value="${s.id}" ${d.subjectId === s.id ? 'selected' : ''}>${s.name}</option>`).join('')}</select></div>
        </div>
        <div class="grid grid-cols-2 gap-3">
          <div><label class="input-label">Duration (minutes)</label><input id="cbt_duration" type="number" class="input" value="${d.duration}" /></div>
          <div><label class="input-label">Rules</label><input id="cbt_rules" class="input" value="${(d.rules || '').replace(/"/g,'&quot;')}" /></div>
        </div>

        <div class="border-t border-slate-100 pt-3">
          <div class="flex items-center justify-between mb-2">
            <h4 class="font-bold text-slate-900">Questions (${d.questions.length})</h4>
            <div class="text-xs text-slate-500">Total marks: ${d.questions.reduce((s, q) => s + q.marks, 0)}</div>
          </div>
          ${d.questions.length === 0 ? `<p class="text-sm text-slate-400 mb-3">No questions yet. Add objective or theory questions below.</p>` : `
            <div class="space-y-2 mb-3">
              ${d.questions.map((q, i) => `<div class="bg-slate-50 rounded-xl p-3">
                <div class="flex items-start justify-between gap-2">
                  <div class="flex-1 min-w-0">
                    <div class="text-xs text-slate-400 mb-0.5">${i + 1}. ${q.type === 'objective' ? 'Objective' : 'Theory'} · ${q.marks} mark(s)</div>
                    <div class="font-semibold text-sm">${q.text}</div>
                    ${q.type === 'objective' ? `<div class="text-xs text-slate-500 mt-1">${q.options.map((o, oi) => `${oi === q.answer ? '✓ ' : ''}${o}`).join(' · ')}</div>` : ''}
                  </div>
                  <button class="btn btn-ghost !p-1 text-rose-600" onclick="removeCbtQuestion(${i})">${icon('trash','w-4 h-4')}</button>
                </div>
              </div>`).join('')}
            </div>
          `}

          <div class="border-2 border-dashed border-slate-200 rounded-xl p-3 space-y-2">
            <div class="flex gap-2">
              <select id="nq_type" class="input !w-40 text-sm" onchange="document.getElementById('nq_objBlock').classList.toggle('hidden', this.value!=='objective')">
                <option value="objective">Objective (MCQ)</option>
                <option value="theory">Theory</option>
              </select>
              <input id="nq_marks" type="number" class="input !w-24 text-sm" value="1" placeholder="Marks" />
            </div>
            <input id="nq_text" class="input text-sm" placeholder="Question text…" />
            <div id="nq_objBlock" class="space-y-1.5">
              ${[0,1,2,3].map(oi => `<div class="flex items-center gap-2">
                <input type="radio" name="nq_correct" value="${oi}" ${oi === 0 ? 'checked' : ''} />
                <input id="nq_opt${oi}" class="input text-sm" placeholder="Option ${oi + 1}" />
              </div>`).join('')}
              <div class="text-xs text-slate-400">Select the radio next to the correct option.</div>
            </div>
            <button class="btn btn-secondary w-full text-sm" onclick="addCbtQuestion()">${icon('plus','w-4 h-4')} Add Question</button>
          </div>
        </div>
      </div>
    `,
    footer: `<button class="btn btn-secondary" onclick="_cbtDraft=null; document.getElementById('modalBackdrop').click()">Cancel</button>
             <button class="btn btn-primary" onclick="saveCbtExam()">${icon('check','w-4 h-4')} Publish Exam</button>`
  });
}

function addCbtQuestion() {
  _captureCbtMeta();
  const type = document.getElementById('nq_type').value;
  const text = document.getElementById('nq_text').value.trim();
  const marks = parseInt(document.getElementById('nq_marks').value) || 1;
  if (!text) { toast('Enter the question text', 'danger'); return; }
  if (type === 'objective') {
    const options = [0,1,2,3].map(oi => document.getElementById('nq_opt' + oi).value.trim()).filter(Boolean);
    if (options.length < 2) { toast('Provide at least two options', 'danger'); return; }
    const correctEl = document.querySelector('input[name="nq_correct"]:checked');
    const answer = correctEl ? parseInt(correctEl.value) : 0;
    if (answer >= options.length) { toast('Correct option must be one you filled in', 'danger'); return; }
    _cbtDraft.questions.push({ id: 'q' + (_cbtDraft.questions.length + 1), type: 'objective', text, options, answer, marks });
  } else {
    _cbtDraft.questions.push({ id: 'q' + (_cbtDraft.questions.length + 1), type: 'theory', text, marks });
  }
  renderCbtBuilder();
}

function removeCbtQuestion(i) {
  _captureCbtMeta();
  _cbtDraft.questions.splice(i, 1);
  renderCbtBuilder();
}

function saveCbtExam() {
  _captureCbtMeta();
  const d = _cbtDraft;
  if (!d.title.trim()) { toast('Exam title is required', 'danger'); return; }
  if (!d.questions.length) { toast('Add at least one question', 'danger'); return; }
  const exam = {
    id: uid('cbt'), schoolId: AUTH.current.schoolId || 'sch_brightlights',
    classId: d.classId, subjectId: d.subjectId, teacherId: AUTH.current.id,
    title: d.title.trim(), durationMins: parseInt(d.duration) || 20, status: 'published',
    dueDate: daysAhead(7), createdAt: now(), rules: d.rules.trim(), questions: d.questions
  };
  DB.insert('cbtExams', exam);
  // Notify students
  COMPUTE.studentsByClass(d.classId).forEach(s => {
    DB.insert('notifications', { id: uid('not'), userId: s.id, title: 'New CBT Exam', body: `${exam.title} — ${exam.questions.length} questions, ${exam.durationMins} min`, type: 'info', read: false, timestamp: now(), link: { view: 'stu_cbt' } });
  });
  _cbtDraft = null;
  document.getElementById('modalBackdrop').click();
  APP.render();
  toast('CBT published to students', 'success');
}

function reviewCbt(examId) {
  const e = DB.find('cbtExams', examId);
  const subs = DB.query('cbtSubmissions', x => x.examId === examId);
  const studentName = id => { const s = DB.find('students', id); return s ? s.name : '—'; };
  modal({
    title: e.title + ' — Submissions',
    size: 'lg',
    body: `
      <div class="space-y-3">
        ${subs.length === 0 ? `<p class="text-sm text-slate-500 text-center py-6">No submissions yet.</p>` : subs.map(sub => `
          <div class="border border-slate-200 rounded-xl p-3">
            <div class="flex items-center gap-3 mb-2">
              ${avatar(studentName(sub.studentId), 'sm')}
              <div class="flex-1 min-w-0">
                <div class="font-semibold text-sm">${studentName(sub.studentId)}</div>
                <div class="text-xs text-slate-500">Submitted ${fdate(sub.submittedAt, { relative: true })}</div>
              </div>
              <div class="text-right">
                <div class="font-bold text-brand-700">${sub.totalScore}/${sub.maxScore}</div>
                <span class="badge ${sub.status === 'graded' ? 'badge-success' : 'badge-warn'}">${sub.status}</span>
              </div>
            </div>
            ${sub.status === 'submitted' && sub.theoryMax > 0 ? `
              <div class="bg-slate-50 rounded-lg p-2 space-y-2">
                <div class="text-xs font-semibold uppercase text-slate-500">Theory answers to mark</div>
                ${e.questions.filter(q => q.type === 'theory').map(q => `
                  <div>
                    <div class="text-xs font-semibold text-slate-700">${q.text} (${q.marks} marks)</div>
                    <div class="text-sm text-slate-600 bg-white border border-slate-200 rounded p-2 my-1">${sub.answers[q.id] || '—'}</div>
                    <input type="number" min="0" max="${q.marks}" id="th_${sub.id}_${q.id}" class="input !w-32 text-sm" placeholder="Marks /${q.marks}" />
                  </div>
                `).join('')}
                <button class="btn btn-primary !py-1.5 !px-3 text-xs" onclick="finalizeCbtGrade('${sub.id}')">${icon('check','w-3.5 h-3.5')} Finalize Grade</button>
              </div>
            ` : `<div class="text-xs text-emerald-700">Auto-graded — objective ${sub.objectiveScore}/${sub.objectiveMax}${sub.theoryMax ? `, theory ${sub.theoryScore}/${sub.theoryMax}` : ''}</div>`}
          </div>
        `).join('')}
      </div>
    `,
    footer: `<button class="btn btn-secondary" onclick="document.getElementById('modalBackdrop').click()">Close</button>`
  });
}

function finalizeCbtGrade(subId) {
  const sub = DB.find('cbtSubmissions', subId);
  const e = DB.find('cbtExams', sub.examId);
  let theoryScore = 0;
  e.questions.filter(q => q.type === 'theory').forEach(q => {
    const el = document.getElementById(`th_${subId}_${q.id}`);
    let m = el ? (parseInt(el.value) || 0) : 0;
    m = Math.max(0, Math.min(q.marks, m));
    theoryScore += m;
  });
  const totalScore = sub.objectiveScore + theoryScore;
  DB.update('cbtSubmissions', subId, { theoryScore, totalScore, status: 'graded', gradedAt: now() });
  const student = DB.find('students', sub.studentId);
  if (student) {
    DB.insert('notifications', { id: uid('not'), userId: student.id, title: 'CBT Result Ready', body: `${e.title}: ${totalScore}/${sub.maxScore}`, type: 'success', read: false, timestamp: now(), link: { view: 'stu_cbt' } });
    DB.insert('notifications', { id: uid('not'), userId: student.parentId, title: 'CBT Result', body: `${student.name} scored ${totalScore}/${sub.maxScore} in ${e.title}`, type: 'info', read: false, timestamp: now() });
  }
  toast(`Graded ${student ? student.name : 'student'} · ${totalScore}/${sub.maxScore}`, 'success');
  reviewCbt(sub.examId);
}
