const fs=require('fs'),path=require('path'),vm=require('vm');
const store={};
const mk=()=>({getItem:k=>k in store?store[k]:null,setItem:(k,v)=>{store[k]=String(v);},removeItem:k=>{delete store[k];}});
const docStub={getElementById:()=>null,querySelector:()=>null,querySelectorAll:()=>[],createElement:()=>({classList:{add(){},remove(){},toggle(){}},style:{},appendChild(){},addEventListener(){},focus(){},click(){},setAttribute(){},remove(){}}),addEventListener:()=>{},body:{},activeElement:{tagName:'BODY'}};
const sb={console,Math,Date,JSON,Array,Object,String,Number,Boolean,parseInt,parseFloat,isNaN,RegExp,Set,Map,Intl,localStorage:mk(),sessionStorage:mk(),document:docStub,navigator:{onLine:true},setTimeout:()=>0,clearTimeout:()=>{},setInterval:()=>0,clearInterval:()=>{},Chart:function(){return{};},FileReader:function(){this.readAsDataURL=()=>{};},URL:{createObjectURL:()=>'blob:',revokeObjectURL:()=>{}},Blob:function(){},history:{replaceState(){},pushState(){}}};
sb.window=sb;sb.globalThis=sb;sb.addEventListener=()=>{};sb.removeEventListener=()=>{};
vm.createContext(sb);
const files=['data.js','ui.js','auth.js','modules/admin.js','modules/teacher.js','modules/parent.js','modules/finance.js','modules/superadmin.js','modules/student.js','modules/shared.js','app.js'];
let combined='';
for(const f of files)combined+='\n;//'+f+'\n'+fs.readFileSync(path.join(__dirname,f),'utf8');
const ep=`;(function(){
  APP.render=()=>{};APP.go=()=>{};
  const acc={
    schooladmin:{id:'sch_brightlights',role:'schooladmin',name:'Admin',schoolId:'sch_brightlights'},
    finance:{id:'fin_001',role:'finance',name:'Finance',schoolId:'sch_brightlights'},
    parent:{id:'par_okafor',role:'parent',name:'Parent',schoolId:'sch_brightlights'},
    superadmin:{id:'sa_001',role:'superadmin',name:'Super'}
  };
  const groups=[
    ['schooladmin',[view_adm_students,view_adm_workforce,view_adm_permissions,view_adm_comms]],
    ['finance',[view_fin_fees,renderFeeStructuresTab,renderActivitiesTab]],
    ['parent',[view_par_dashboard,view_par_consent]],
    ['superadmin',[view_sa_analytics]]
  ];
  let pass=0,fail=0;
  for(const[role,fns]of groups){AUTH.current=acc[role];APP.params={};for(const f of fns){
    try{const out=f();if(typeof out!=='string'||out.length<5){console.log('EMPTY '+role+':'+f.name);fail++;continue;}pass++;}
    catch(e){console.log('THROW '+role+':'+f.name+' -> '+e.message);fail++;}
  }}
  // Spot checks
  const nav=APP.navFor('schooladmin').find(n=>n.key==='adm_people');
  console.log('Nav label:',nav?nav.label:'NOT FOUND');
  const wf=APP.navFor('schooladmin').find(n=>n.key==='adm_workforce');
  console.log('Workforce hub label:',wf?wf.label:'NOT FOUND');
  // Check permissions tab is in workforce hub
  AUTH.current=acc.schooladmin; APP.params={workforceTab:'permissions'};
  try{const out=view_adm_permissions();console.log('Permissions report renders:',typeof out==='string'&&out.length>100?'YES':'NO (len='+out.length+')');}catch(e){console.log('Permissions ERROR:',e.message);fail++;}
  // Check date filter renders
  AUTH.current=acc.superadmin; APP.params={anaFrom:'2026-01-01',anaTo:'2026-06-08'};
  try{const out=view_sa_analytics();console.log('Analytics with date range renders:',typeof out==='string'&&out.includes('2026-01-01')?'YES':'NO');}catch(e){console.log('Analytics ERROR:',e.message);fail++;}
  console.log('\\nRESULT: '+pass+' passed, '+fail+' failed');
  globalThis.__smokeFail=fail;
})();`;
vm.runInContext(combined+ep,sb);
process.exit(sb.__smokeFail?1:0);
