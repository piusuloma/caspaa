/* ============================================================
   CASPAA DATA LAYER
   - LocalStorage-backed mock database
   - Seed data simulates a real Lagos school
   ============================================================ */

const DB_KEY = 'caspaa_db_v1';
const SESSION_KEY = 'caspaa_session_v1';

/* ---------- Utility ---------- */
const uid = (prefix = 'id') => `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
const today = () => new Date().toISOString().slice(0, 10);
const now = () => new Date().toISOString();
const daysAgo = (n) => { const d = new Date(); d.setDate(d.getDate() - n); return d.toISOString().slice(0, 10); };
const daysAhead = (n) => { const d = new Date(); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };
const NGN = (n) => '₦' + Number(n).toLocaleString('en-NG', { maximumFractionDigits: 0 });

/* ---------- Seed Generator ---------- */
function seedDatabase() {
  const schoolId = 'sch_brightlights';

  const classes = [
    { id: 'cls_nur1', schoolId, name: 'Nursery 1', level: 'Nursery', teacherId: 'tch_funke' },
    { id: 'cls_nur2', schoolId, name: 'Nursery 2', level: 'Nursery', teacherId: 'tch_funke' },
    { id: 'cls_pry1', schoolId, name: 'Primary 1', level: 'Primary', teacherId: 'tch_adamu' },
    { id: 'cls_pry2', schoolId, name: 'Primary 2', level: 'Primary', teacherId: 'tch_adamu' },
    { id: 'cls_pry3', schoolId, name: 'Primary 3', level: 'Primary', teacherId: 'tch_chioma' },
    { id: 'cls_jss1', schoolId, name: 'JSS 1', level: 'Secondary', teacherId: 'tch_emeka' },
    { id: 'cls_jss2', schoolId, name: 'JSS 2', level: 'Secondary', teacherId: 'tch_emeka' },
    { id: 'cls_sss1', schoolId, name: 'SSS 1', level: 'Secondary', teacherId: 'tch_bola' },
  ];

  const subjects = [
    { id: 'sub_math', name: 'Mathematics' },
    { id: 'sub_eng',  name: 'English Language' },
    { id: 'sub_sci',  name: 'Basic Science' },
    { id: 'sub_soc',  name: 'Social Studies' },
    { id: 'sub_yor',  name: 'Yoruba' },
    { id: 'sub_civ',  name: 'Civic Education' },
    { id: 'sub_ict',  name: 'Computer Studies' },
    { id: 'sub_crk',  name: 'Christian Religious Knowledge' }
  ];

  const teachers = [
    { id: 'tch_funke',  schoolId, name: 'Mrs. Funke Adeyemi',  email: 'funke@brightlights.ng',  phone: '08012345601', staffType: 'Academic', subjects: ['sub_yor', 'sub_eng'], classes: ['cls_nur1','cls_nur2'], hireDate: '2022-09-01', salary: 180000, role: 'teacher', bank: { name: 'GTBank', account: '0123456701' }, dob: '1990-04-12' },
    { id: 'tch_adamu',  schoolId, name: 'Mr. Adamu Ibrahim',   email: 'adamu@brightlights.ng', phone: '08012345602', staffType: 'Academic', subjects: ['sub_math', 'sub_sci'], classes: ['cls_pry1','cls_pry2','cls_jss1'], hireDate: '2021-09-01', salary: 220000, role: 'teacher', bank: { name: 'Access Bank', account: '0123456702' }, dob: '1985-08-22' },
    { id: 'tch_chioma', schoolId, name: 'Miss Chioma Okeke',   email: 'chioma@brightlights.ng',phone: '08012345603', staffType: 'Academic', subjects: ['sub_eng', 'sub_soc'], classes: ['cls_pry3','cls_jss1'], hireDate: '2023-01-15', salary: 200000, role: 'teacher', bank: { name: 'UBA', account: '0123456703' }, dob: '1992-11-30' },
    { id: 'tch_emeka',  schoolId, name: 'Mr. Emeka Nwosu',     email: 'emeka@brightlights.ng', phone: '08012345604', staffType: 'Academic', subjects: ['sub_sci', 'sub_ict'], classes: ['cls_jss1','cls_jss2'], hireDate: '2020-09-01', salary: 240000, role: 'teacher', bank: { name: 'Zenith', account: '0123456704' }, dob: '1987-03-05' },
    { id: 'tch_bola',   schoolId, name: 'Mrs. Bola Akinwale',  email: 'bola@brightlights.ng',  phone: '08012345605', staffType: 'Academic', subjects: ['sub_civ', 'sub_crk'], classes: ['cls_sss1'], hireDate: '2019-09-01', salary: 260000, role: 'teacher', bank: { name: 'First Bank', account: '0123456705' }, dob: '1980-07-18' },
    // Non-academic staff
    { id: 'stf_bursar', schoolId, name: 'Mr. Olumide Sanya',    email: 'bursar@brightlights.ng', phone: '08012345610', staffType: 'Finance',        role: 'Bursar',           classes: [], subjects: [], hireDate: '2018-01-10', salary: 280000, bank: { name: 'GTBank', account: '0123456710' }, dob: '1976-02-08' },
    { id: 'stf_sec',    schoolId, name: 'Miss Halima Yusuf',    email: 'secretary@brightlights.ng', phone: '08012345611', staffType: 'Administration', role: 'Secretary',       classes: [], subjects: [], hireDate: '2022-03-01', salary: 130000, bank: { name: 'Access',   account: '0123456711' }, dob: '1995-09-21' },
    { id: 'stf_sec2',   schoolId, name: 'Mr. Sola Adebanjo',    email: 'security@brightlights.ng',  phone: '08012345612', staffType: 'Operations',     role: 'Security Guard',  classes: [], subjects: [], hireDate: '2020-06-15', salary: 75000,  bank: { name: 'UBA',      account: '0123456712' }, dob: '1978-10-04' },
    { id: 'stf_it',     schoolId, name: 'Mr. Chuka Eze',        email: 'ict@brightlights.ng',       phone: '08012345613', staffType: 'ICT',            role: 'IT Support',       classes: [], subjects: [], hireDate: '2024-02-12', salary: 180000, bank: { name: 'Kuda',     account: '0123456713' }, dob: '1996-12-29' },
    { id: 'stf_driver', schoolId, name: 'Mr. Tope Adigun',      email: 'driver@brightlights.ng',    phone: '08012345614', staffType: 'Transport',      role: 'School Bus Driver',classes: [], subjects: [], hireDate: '2021-09-01', salary: 95000,  bank: { name: 'Opay',     account: '0123456714' }, dob: '1973-05-14' }
  ];

  const parents = [
    { id: 'par_okafor', schoolId, name: 'Mr. Tunde Okafor',    email: 'parent@demo.ng',         phone: '08099999001', occupation: 'Software Engineer', monthlyIncome: 850000, address: '12 Admiralty Way, Lekki' },
    { id: 'par_bello',  schoolId, name: 'Mrs. Aisha Bello',    email: 'aisha.bello@gmail.com',  phone: '08099999002', occupation: 'Doctor', monthlyIncome: 1200000, address: '5 Bourdillon Rd, Ikoyi' },
    { id: 'par_eze',    schoolId, name: 'Mr. Chinedu Eze',     email: 'eze.chinedu@yahoo.com',  phone: '08099999003', occupation: 'Trader', monthlyIncome: 420000, address: '8 Allen Avenue, Ikeja' },
    { id: 'par_musa',   schoolId, name: 'Mrs. Hauwa Musa',     email: 'hauwa.m@outlook.com',    phone: '08099999004', occupation: 'Civil Servant', monthlyIncome: 320000, address: '22 Adeniyi Jones, Ikeja' },
    { id: 'par_lawal',  schoolId, name: 'Mr. Kunle Lawal',     email: 'klawal@gmail.com',       phone: '08099999005', occupation: 'Banker', monthlyIncome: 780000, address: '7 Banana Island' }
  ];

  const students = [
    { id: 'stu_001', schoolId, name: 'Chiamaka Okafor', admissionNo: 'BL/2024/001', classId: 'cls_pry3', dob: '2016-04-12', gender: 'F', parentId: 'par_okafor', photo: null, admissionDate: '2024-09-01', bloodGroup: 'O+', status: 'active' },
    { id: 'stu_002', schoolId, name: 'Tobi Okafor',     admissionNo: 'BL/2024/002', classId: 'cls_jss1', dob: '2013-08-22', gender: 'M', parentId: 'par_okafor', photo: null, admissionDate: '2024-09-01', bloodGroup: 'O+', status: 'active' },
    { id: 'stu_003', schoolId, name: 'Zainab Bello',    admissionNo: 'BL/2024/003', classId: 'cls_jss2', dob: '2012-02-10', gender: 'F', parentId: 'par_bello',  photo: null, admissionDate: '2023-09-01', bloodGroup: 'A+', status: 'active' },
    { id: 'stu_004', schoolId, name: 'Yusuf Bello',     admissionNo: 'BL/2024/004', classId: 'cls_pry2', dob: '2017-06-30', gender: 'M', parentId: 'par_bello',  photo: null, admissionDate: '2024-09-01', bloodGroup: 'A+', status: 'active' },
    { id: 'stu_005', schoolId, name: 'Daniel Eze',      admissionNo: 'BL/2024/005', classId: 'cls_pry1', dob: '2018-11-05', gender: 'M', parentId: 'par_eze',    photo: null, admissionDate: '2024-09-01', bloodGroup: 'B+', status: 'active' },
    { id: 'stu_006', schoolId, name: 'Ngozi Eze',       admissionNo: 'BL/2024/006', classId: 'cls_pry3', dob: '2016-01-18', gender: 'F', parentId: 'par_eze',    photo: null, admissionDate: '2024-09-01', bloodGroup: 'B+', status: 'active' },
    { id: 'stu_007', schoolId, name: 'Ibrahim Musa',    admissionNo: 'BL/2024/007', classId: 'cls_nur2', dob: '2020-03-15', gender: 'M', parentId: 'par_musa',   photo: null, admissionDate: '2024-09-01', bloodGroup: 'AB+', status: 'active' },
    { id: 'stu_008', schoolId, name: 'Fatima Musa',     admissionNo: 'BL/2024/008', classId: 'cls_sss1', dob: '2009-07-09', gender: 'F', parentId: 'par_musa',   photo: null, admissionDate: '2022-09-01', bloodGroup: 'AB+', status: 'active' },
    { id: 'stu_009', schoolId, name: 'Ade Lawal',       admissionNo: 'BL/2024/009', classId: 'cls_jss1', dob: '2013-12-01', gender: 'M', parentId: 'par_lawal',  photo: null, admissionDate: '2023-09-01', bloodGroup: 'O-', status: 'active' },
    { id: 'stu_010', schoolId, name: 'Bisi Lawal',      admissionNo: 'BL/2024/010', classId: 'cls_pry2', dob: '2017-09-25', gender: 'F', parentId: 'par_lawal',  photo: null, admissionDate: '2024-09-01', bloodGroup: 'O-', status: 'active' }
  ];

  // Fee structure per class (yearly, NGN)
  const feeStructures = [
    { id: uid('fee'), schoolId, classId: 'cls_nur1', term: '1st Term 2025/26', tuition: 180000, books: 25000, uniform: 18000, pta: 5000, dueDate: daysAhead(15) },
    { id: uid('fee'), schoolId, classId: 'cls_nur2', term: '1st Term 2025/26', tuition: 190000, books: 25000, uniform: 18000, pta: 5000, dueDate: daysAhead(15) },
    { id: uid('fee'), schoolId, classId: 'cls_pry1', term: '1st Term 2025/26', tuition: 220000, books: 30000, uniform: 20000, pta: 5000, dueDate: daysAhead(15) },
    { id: uid('fee'), schoolId, classId: 'cls_pry2', term: '1st Term 2025/26', tuition: 220000, books: 30000, uniform: 20000, pta: 5000, dueDate: daysAhead(15) },
    { id: uid('fee'), schoolId, classId: 'cls_pry3', term: '1st Term 2025/26', tuition: 240000, books: 32000, uniform: 20000, pta: 5000, dueDate: daysAhead(15) },
    { id: uid('fee'), schoolId, classId: 'cls_jss1', term: '1st Term 2025/26', tuition: 280000, books: 38000, uniform: 22000, pta: 7500, dueDate: daysAhead(15) },
    { id: uid('fee'), schoolId, classId: 'cls_jss2', term: '1st Term 2025/26', tuition: 290000, books: 38000, uniform: 22000, pta: 7500, dueDate: daysAhead(15) },
    { id: uid('fee'), schoolId, classId: 'cls_sss1', term: '1st Term 2025/26', tuition: 320000, books: 42000, uniform: 25000, pta: 7500, dueDate: daysAhead(15) }
  ];

  // Invoices — generated from fee structures per student. Some paid, some partial, some outstanding.
  const invoices = [];
  students.forEach((s, idx) => {
    const fs = feeStructures.find(f => f.classId === s.classId);
    const total = fs.tuition + fs.books + fs.uniform + fs.pta;
    // Spread: paid, partial, outstanding rotation
    const status = idx % 3 === 0 ? 'paid' : (idx % 3 === 1 ? 'partial' : 'outstanding');
    const paid = status === 'paid' ? total : (status === 'partial' ? Math.round(total * 0.6) : 0);
    invoices.push({
      id: uid('inv'),
      schoolId,
      studentId: s.id,
      term: fs.term,
      lineItems: [
        { name: 'Tuition Fee', amount: fs.tuition },
        { name: 'Books & Materials', amount: fs.books },
        { name: 'Uniform', amount: fs.uniform },
        { name: 'PTA Levy', amount: fs.pta }
      ],
      total,
      paid,
      balance: total - paid,
      status,
      dueDate: fs.dueDate,
      createdAt: daysAgo(30)
    });
  });

  // Payment transactions for paid/partial invoices
  const transactions = [];
  invoices.forEach(inv => {
    if (inv.paid > 0) {
      transactions.push({
        id: uid('txn'),
        schoolId,
        invoiceId: inv.id,
        studentId: inv.studentId,
        amount: inv.paid,
        method: ['card', 'transfer', 'ussd'][Math.floor(Math.random() * 3)],
        reference: 'CSP-' + Math.random().toString(36).slice(2, 10).toUpperCase(),
        status: 'successful',
        gateway: 'Paystack',
        timestamp: daysAgo(Math.floor(Math.random() * 25)),
        reconciled: true
      });
    }
  });

  // Attendance — last 14 days for all students
  const attendance = [];
  for (let d = 13; d >= 0; d--) {
    const date = daysAgo(d);
    const wd = new Date(date).getDay();
    if (wd === 0 || wd === 6) continue; // weekends
    students.forEach(s => {
      const r = Math.random();
      let status = 'present';
      if (r > 0.94) status = 'absent';
      else if (r > 0.88) status = 'late';
      attendance.push({ id: uid('att'), schoolId, studentId: s.id, classId: s.classId, date, status, recordedBy: classes.find(c => c.id === s.classId).teacherId });
    });
  }

  // Results — CA + Exam for each student per subject
  const results = [];
  students.forEach(s => {
    subjects.slice(0, 6).forEach(sub => {
      const ca1 = Math.floor(Math.random() * 15) + 5;       // 5-20
      const ca2 = Math.floor(Math.random() * 15) + 5;       // 5-20
      const exam = Math.floor(Math.random() * 40) + 25;      // 25-65
      const total = ca1 + ca2 + exam;
      let grade = 'F';
      if (total >= 75) grade = 'A';
      else if (total >= 60) grade = 'B';
      else if (total >= 50) grade = 'C';
      else if (total >= 45) grade = 'D';
      else if (total >= 40) grade = 'E';
      results.push({
        id: uid('res'), schoolId, studentId: s.id, classId: s.classId,
        subjectId: sub.id, term: '1st Term 2025/26',
        ca1, ca2, exam, total, grade,
        comment: '', approved: Math.random() > 0.3
      });
    });
  });

  // Assignments
  const assignments = [
    { id: uid('asn'), schoolId, classId: 'cls_jss1', subjectId: 'sub_math', teacherId: 'tch_adamu', title: 'Algebra Practice - Set 3', description: 'Solve exercises 1-15 from page 42 of your textbook. Show all working steps.', dueDate: daysAhead(3), createdAt: daysAgo(2), submissions: [] },
    { id: uid('asn'), schoolId, classId: 'cls_jss1', subjectId: 'sub_eng',  teacherId: 'tch_chioma', title: 'Essay: My Future Career', description: 'Write a 300-word essay on what you want to become and why.', dueDate: daysAhead(5), createdAt: daysAgo(1), submissions: [] },
    { id: uid('asn'), schoolId, classId: 'cls_pry3', subjectId: 'sub_math', teacherId: 'tch_adamu', title: 'Multiplication Tables', description: 'Memorize and recite multiplication tables 6-9 by Monday.', dueDate: daysAhead(2), createdAt: daysAgo(3), submissions: [{ studentId: 'stu_001', submittedAt: now(), grade: null }] },
    { id: uid('asn'), schoolId, classId: 'cls_sss1', subjectId: 'sub_civ',  teacherId: 'tch_bola',  title: 'Civic Duties Project', description: 'Research and write about three civic duties of a Nigerian citizen.', dueDate: daysAhead(7), createdAt: daysAgo(1), submissions: [] }
  ];

  // Messages — conversations between parent & teacher
  const conversations = [
    {
      id: 'conv_001', schoolId,
      participants: ['par_okafor', 'tch_adamu'],
      messages: [
        { from: 'par_okafor', text: 'Good morning. How is Tobi performing in Maths this term?', timestamp: daysAgo(2) },
        { from: 'tch_adamu', text: 'Good morning sir. Tobi is improving steadily. He scored 78 in his last CA. Just needs more practice on word problems.', timestamp: daysAgo(2) },
        { from: 'par_okafor', text: 'Thank you. I will work with him at home.', timestamp: daysAgo(2) }
      ]
    },
    {
      id: 'conv_002', schoolId,
      participants: ['par_bello', 'tch_emeka'],
      messages: [
        { from: 'tch_emeka', text: 'Mrs. Bello, please ensure Zainab brings her science notebook tomorrow for the practical.', timestamp: daysAgo(1) },
        { from: 'par_bello', text: 'Noted, thank you. I will pack it tonight.', timestamp: daysAgo(1) }
      ]
    }
  ];

  // Announcements (broadcast)
  const announcements = [
    { id: uid('ann'), schoolId, title: 'Mid-term Break', body: 'School will close for mid-term break from Friday 6th December and resume on Monday 16th December. Have a restful break.', audience: 'all', sentBy: 'sch_brightlights', timestamp: daysAgo(3) },
    { id: uid('ann'), schoolId, title: 'PTA Meeting', body: 'A PTA meeting holds this Saturday at 10am in the school hall. All parents are encouraged to attend.', audience: 'parents', sentBy: 'sch_brightlights', timestamp: daysAgo(7) },
    { id: uid('ann'), schoolId, title: 'Sports Day', body: 'Annual inter-house sports day comes up on the 28th of this month. Students should come in their house colours.', audience: 'all', sentBy: 'sch_brightlights', timestamp: daysAgo(5) }
  ];

  // Inventory
  const mkHist = (items) => items.map((it, idx) => ({ ...it, history: [
    { delta: it.quantity, reason: 'Opening stock', by: 'sch_brightlights', timestamp: daysAgo(60 - idx) }
  ]}));
  const inventory = mkHist([
    { id: uid('inv'), schoolId, name: 'Mathematics Textbook (JSS1)', category: 'Books', quantity: 48, minStock: 20, unitCost: 4500, supplier: 'Macmillan' },
    { id: uid('inv'), schoolId, name: 'English Workbook (Primary)', category: 'Books', quantity: 15, minStock: 25, unitCost: 3200, supplier: 'University Press' },
    { id: uid('inv'), schoolId, name: 'School Uniform - Daily Wear', category: 'Uniform', quantity: 80, minStock: 30, unitCost: 8500, supplier: 'Bright Tailors' },
    { id: uid('inv'), schoolId, name: 'A4 Plain Sheets (Reams)', category: 'Stationery', quantity: 12, minStock: 10, unitCost: 4800, supplier: 'Office Mart' },
    { id: uid('inv'), schoolId, name: 'Whiteboard Markers (Box)', category: 'Stationery', quantity: 8, minStock: 5, unitCost: 2400, supplier: 'Office Mart' },
    { id: uid('inv'), schoolId, name: 'Projector - Epson EB-X06', category: 'Equipment', quantity: 3, minStock: 1, unitCost: 285000, supplier: 'TechZone' }
  ]);
  // Add a few realistic movements
  inventory[0].history.push({ delta: -12, reason: 'Issued to JSS1', by: 'sch_brightlights', timestamp: daysAgo(20) });
  inventory[1].history.push({ delta: -10, reason: 'Distributed to Primary 3', by: 'sch_brightlights', timestamp: daysAgo(15) });
  inventory[3].history.push({ delta: -3, reason: 'Office consumption', by: 'sch_brightlights', timestamp: daysAgo(7) });
  inventory[4].history.push({ delta: -2, reason: 'Staff room use', by: 'sch_brightlights', timestamp: daysAgo(5) });

  // Discipline records
  const discipline = [
    { id: uid('dis'), schoolId, studentId: 'stu_002', type: 'commendation', points: 5, note: 'Helped a junior student carry books', recordedBy: 'tch_adamu', date: daysAgo(5) },
    { id: uid('dis'), schoolId, studentId: 'stu_009', type: 'misconduct', points: -2, note: 'Late to morning assembly twice this week', recordedBy: 'tch_adamu', date: daysAgo(3) },
    { id: uid('dis'), schoolId, studentId: 'stu_003', type: 'commendation', points: 10, note: 'Top scorer in Science quiz', recordedBy: 'tch_emeka', date: daysAgo(8) }
  ];

  // Loans
  const loans = [
    {
      id: uid('loan'), schoolId, parentId: 'par_eze', studentIds: ['stu_005', 'stu_006'],
      amount: 250000, term: 6, interestRate: 5,
      totalRepayment: 262500, monthlyPayment: 43750,
      status: 'active', creditScore: 685,
      appliedAt: daysAgo(20), approvedAt: daysAgo(19),
      repayments: [
        { dueDate: daysAgo(5), amount: 43750, paid: true, paidAt: daysAgo(5) },
        { dueDate: daysAhead(25), amount: 43750, paid: false },
        { dueDate: daysAhead(55), amount: 43750, paid: false },
        { dueDate: daysAhead(85), amount: 43750, paid: false },
        { dueDate: daysAhead(115), amount: 43750, paid: false },
        { dueDate: daysAhead(145), amount: 43750, paid: false }
      ]
    },
    {
      id: uid('loan'), schoolId, parentId: 'par_musa', studentIds: ['stu_007', 'stu_008'],
      amount: 320000, term: 6, interestRate: 5,
      totalRepayment: 336000, monthlyPayment: 56000,
      status: 'pending', creditScore: 640,
      reason: 'School fees for Ibrahim (Nursery 2) and Fatima (SSS 1) this term',
      appliedAt: daysAgo(1),
      repayments: []
    }
  ];

  // Timetable for JSS1 Monday-Friday (sample)
  const timetable = [
    { id: uid('tt'), schoolId, classId: 'cls_jss1', day: 'Monday',    period: 1, time: '08:00-08:40', subjectId: 'sub_math', teacherId: 'tch_adamu' },
    { id: uid('tt'), schoolId, classId: 'cls_jss1', day: 'Monday',    period: 2, time: '08:40-09:20', subjectId: 'sub_eng',  teacherId: 'tch_chioma' },
    { id: uid('tt'), schoolId, classId: 'cls_jss1', day: 'Monday',    period: 3, time: '09:20-10:00', subjectId: 'sub_sci',  teacherId: 'tch_emeka' },
    { id: uid('tt'), schoolId, classId: 'cls_jss1', day: 'Tuesday',   period: 1, time: '08:00-08:40', subjectId: 'sub_eng',  teacherId: 'tch_chioma' },
    { id: uid('tt'), schoolId, classId: 'cls_jss1', day: 'Tuesday',   period: 2, time: '08:40-09:20', subjectId: 'sub_math', teacherId: 'tch_adamu' },
    { id: uid('tt'), schoolId, classId: 'cls_jss1', day: 'Wednesday', period: 1, time: '08:00-08:40', subjectId: 'sub_sci',  teacherId: 'tch_emeka' },
    { id: uid('tt'), schoolId, classId: 'cls_jss1', day: 'Wednesday', period: 2, time: '08:40-09:20', subjectId: 'sub_soc',  teacherId: 'tch_chioma' },
    { id: uid('tt'), schoolId, classId: 'cls_jss1', day: 'Thursday',  period: 1, time: '08:00-08:40', subjectId: 'sub_math', teacherId: 'tch_adamu' },
    { id: uid('tt'), schoolId, classId: 'cls_jss1', day: 'Thursday',  period: 2, time: '08:40-09:20', subjectId: 'sub_ict',  teacherId: 'tch_emeka' },
    { id: uid('tt'), schoolId, classId: 'cls_jss1', day: 'Friday',    period: 1, time: '08:00-08:40', subjectId: 'sub_yor',  teacherId: 'tch_funke' },
    { id: uid('tt'), schoolId, classId: 'cls_jss1', day: 'Friday',    period: 2, time: '08:40-09:20', subjectId: 'sub_civ',  teacherId: 'tch_bola' }
  ];

  // Lesson plans
  const lessonPlans = [
    { id: uid('lp'), schoolId, teacherId: 'tch_adamu', classId: 'cls_jss1', subjectId: 'sub_math', week: 'Week 6', topic: 'Quadratic Equations', objectives: 'Students will be able to solve simple quadratic equations using factorization.', activities: 'Examples, group work, board exercises', resources: 'Textbook ch. 5, whiteboard', createdAt: daysAgo(4) },
    { id: uid('lp'), schoolId, teacherId: 'tch_chioma', classId: 'cls_jss1', subjectId: 'sub_eng', week: 'Week 6', topic: 'Adjectives and Adverbs', objectives: 'Identify and use adjectives and adverbs correctly.', activities: 'Reading passage, sentence construction', resources: 'Workbook, flashcards', createdAt: daysAgo(2) }
  ];

  // Expense ledger
  const expenses = [
    { id: uid('exp'), schoolId, category: 'Salaries', amount: 1100000, description: 'November teacher salaries', date: daysAgo(15), recordedBy: 'sch_brightlights' },
    { id: uid('exp'), schoolId, category: 'Utilities', amount: 85000, description: 'Diesel for generator', date: daysAgo(10), recordedBy: 'sch_brightlights' },
    { id: uid('exp'), schoolId, category: 'Maintenance', amount: 120000, description: 'Classroom paint and repairs', date: daysAgo(20), recordedBy: 'sch_brightlights' },
    { id: uid('exp'), schoolId, category: 'Supplies', amount: 65000, description: 'Stationery and consumables', date: daysAgo(7), recordedBy: 'sch_brightlights' },
    { id: uid('exp'), schoolId, category: 'Internet', amount: 35000, description: 'Monthly internet subscription', date: daysAgo(5), recordedBy: 'sch_brightlights' }
  ];

  // Audit log
  const auditLog = [
    { id: uid('aud'), schoolId, actor: 'sch_brightlights', action: 'created_school', target: 'Bright Lights Academy', timestamp: daysAgo(30) },
    { id: uid('aud'), schoolId, actor: 'sch_brightlights', action: 'added_student', target: 'Chiamaka Okafor', timestamp: daysAgo(30) },
    { id: uid('aud'), schoolId, actor: 'tch_adamu', action: 'submitted_result', target: 'JSS1 Mathematics', timestamp: daysAgo(2) }
  ];

  // Schools (for super admin view)
  const schools = [
    { id: 'sch_brightlights', name: 'Bright Lights Academy', proprietor: 'Mr. Olusegun Adebayo', email: 'admin@brightlights.ng', phone: '+234 802 555 0001', address: '15 Liberty Estate, Lekki, Lagos', students: 10, teachers: 5, subscriptionPlan: 'Professional', monthlyFee: 75000, status: 'active', joinedAt: daysAgo(180), kyc: { regNumber: 'RC-228491', ownerNIN: '12345678901', cacUploaded: true, accreditation: 'Lagos State Ministry of Education' }, nextRenewal: daysAhead(28), autoRenew: true },
    { id: 'sch_horizon', name: 'Horizon International School', proprietor: 'Mrs. Adaeze Nkem', email: 'admin@horizon.ng', phone: '+234 803 555 0002', address: '8 Adetokunbo Ademola, VI, Lagos', students: 380, teachers: 28, subscriptionPlan: 'Enterprise', monthlyFee: 280000, status: 'active', joinedAt: daysAgo(240), kyc: { regNumber: 'RC-184502', ownerNIN: '22345678901', cacUploaded: true, accreditation: 'Lagos State Ministry of Education' }, nextRenewal: daysAhead(12), autoRenew: true },
    { id: 'sch_excellence', name: 'Excellence Group of Schools', proprietor: 'Pastor John Adekola', email: 'office@excellence.ng', phone: '+234 805 555 0003', address: '22 Awolowo Way, Ikeja, Lagos', students: 215, teachers: 18, subscriptionPlan: 'Professional', monthlyFee: 150000, status: 'active', joinedAt: daysAgo(120), kyc: { regNumber: 'RC-301204', ownerNIN: '32345678901', cacUploaded: true, accreditation: 'Lagos State Ministry of Education' }, nextRenewal: daysAhead(5), autoRenew: false },
    { id: 'sch_montessori', name: 'Little Stars Montessori', proprietor: 'Dr. Ngozi Iheanacho', email: 'info@littlestars.ng', phone: '+234 806 555 0004', address: '5 Banana Island Rd, Ikoyi', students: 95, teachers: 11, subscriptionPlan: 'Essential', monthlyFee: 45000, status: 'trial', joinedAt: daysAgo(15), kyc: { regNumber: 'RC-410992', ownerNIN: '42345678901', cacUploaded: false, accreditation: 'Pending' }, nextRenewal: daysAhead(45), autoRenew: false },
    { id: 'sch_anchor', name: 'Anchor Comprehensive College', proprietor: 'Chief Tunde Bakare', email: 'admin@anchorcollege.ng', phone: '+234 807 555 0005', address: '14 Magodo Phase 2, Lagos', students: 540, teachers: 38, subscriptionPlan: 'Enterprise', monthlyFee: 380000, status: 'active', joinedAt: daysAgo(310), kyc: { regNumber: 'RC-100348', ownerNIN: '52345678901', cacUploaded: true, accreditation: 'Lagos State Ministry of Education' }, nextRenewal: daysAhead(18), autoRenew: true },
    { id: 'sch_paula', name: 'Paula Heights School', proprietor: 'Mrs. Paula Okeke', email: 'paula@pauleheights.ng', phone: '+234 808 555 0006', address: '11 Festac Town, Lagos', students: 140, teachers: 12, subscriptionPlan: 'Professional', monthlyFee: 95000, status: 'suspended', joinedAt: daysAgo(95), kyc: { regNumber: 'RC-220871', ownerNIN: '62345678901', cacUploaded: true, accreditation: 'Lagos State Ministry of Education' }, nextRenewal: daysAgo(8), autoRenew: false }
  ];

  // Notifications (in-app)
  const notifications = [
    { id: uid('not'), userId: 'par_okafor', title: 'Fee Reminder', body: 'School fees for 1st Term are due in 15 days', type: 'warn', read: false, timestamp: daysAgo(1) },
    { id: uid('not'), userId: 'par_okafor', title: 'New Announcement', body: 'PTA Meeting this Saturday', type: 'info', read: false, timestamp: daysAgo(7) },
    { id: uid('not'), userId: 'par_okafor', title: 'Assignment Posted', body: 'New Maths assignment for Tobi', type: 'info', read: true, timestamp: daysAgo(2) },
    { id: uid('not'), userId: 'tch_adamu', title: 'Result Awaiting Approval', body: 'JSS1 Mathematics results submitted', type: 'info', read: false, timestamp: daysAgo(1) }
  ];

  // Leave requests (HR)
  const leaveRequests = [
    { id: uid('lv'), schoolId, staffId: 'tch_chioma', type: 'Casual', from: daysAhead(7),  to: daysAhead(9),  reason: 'Family commitment',     status: 'pending',  requestedAt: daysAgo(1) },
    { id: uid('lv'), schoolId, staffId: 'stf_sec',    type: 'Sick',   from: daysAgo(2),   to: daysAgo(1),    reason: 'Medical appointment',   status: 'approved', requestedAt: daysAgo(3), decidedAt: daysAgo(2) },
    { id: uid('lv'), schoolId, staffId: 'tch_emeka',  type: 'Annual', from: daysAhead(20), to: daysAhead(27), reason: 'Annual vacation leave', status: 'pending',  requestedAt: daysAgo(2) }
  ];

  // Staff attendance (clock-in records) for the last 5 working days
  const staffAttendance = [];
  for (let d = 5; d >= 0; d--) {
    const date = daysAgo(d);
    const wd = new Date(date).getDay();
    if (wd === 0 || wd === 6) continue;
    teachers.forEach(t => {
      if (Math.random() > 0.92) return; // ~8% absent
      const lateMins = Math.random() > 0.85 ? Math.floor(Math.random() * 45) + 1 : 0;
      staffAttendance.push({
        id: uid('satt'), schoolId, staffId: t.id, date,
        clockIn: lateMins ? `08:${String(lateMins).padStart(2,'0')}` : '07:' + String(45 + Math.floor(Math.random()*10)).padStart(2,'0'),
        clockOut: '15:' + String(20 + Math.floor(Math.random()*30)).padStart(2,'0'),
        status: lateMins ? 'late' : 'present'
      });
    });
  }

  // Support tickets (operator side)
  const supportTickets = [
    { id: 'tkt_001', schoolId: 'sch_horizon',      requester: 'Mrs. Adaeze Nkem',     subject: 'Bulk-upload failing for SSS3 class',          description: 'Trying to bulk upload 42 students for SSS3 but the CSV fails with "class not found" even though SSS3 exists.', priority: 'high',   status: 'in_progress', channel: 'whatsapp', assignedTo: 'team_sup', createdAt: daysAgo(1), slaHours: 4,  notes: [{ by: 'team_sup', text: 'Investigating CSV format', timestamp: daysAgo(1), internal: true }] },
    { id: 'tkt_002', schoolId: 'sch_brightlights', requester: 'Mr. Olusegun Adebayo', subject: 'Need to bulk-resend WhatsApp invites',         description: 'About 25 parents never received their WhatsApp invitation. Can you resend in bulk?', priority: 'low',    status: 'open',        channel: 'platform',  assignedTo: null,         createdAt: daysAgo(2), slaHours: 48, notes: [] },
    { id: 'tkt_003', schoolId: 'sch_montessori',   requester: 'Dr. Ngozi Iheanacho',  subject: 'Paystack account name shows wrong school',     description: 'When parents pay, the Paystack confirmation shows "Little Star" not "Little Stars Montessori".', priority: 'medium', status: 'resolved',    channel: 'whatsapp',  assignedTo: 'team_sup', createdAt: daysAgo(6), slaHours: 24, notes: [{ by: 'team_sup', text: 'Updated business name with Paystack', timestamp: daysAgo(5), internal: false }, { by: 'team_sup', text: 'Confirmed working by Mrs. Iheanacho', timestamp: daysAgo(5), internal: true }] },
    { id: 'tkt_004', schoolId: 'sch_anchor',       requester: 'Chief Tunde Bakare',   subject: 'How do I export the annual broadsheet?',       description: 'Need to send broadsheets to the proprietor association by Friday.', priority: 'medium', status: 'open',        channel: 'platform',  assignedTo: null,         createdAt: daysAgo(0), slaHours: 24, notes: [] },
    { id: 'tkt_005', schoolId: 'sch_excellence',   requester: 'Pastor John Adekola',  subject: 'Two teachers cannot login',                     description: 'Mrs. Okafor and Mr. Adeyemi both report invalid password despite resets.', priority: 'high',   status: 'escalated',   channel: 'whatsapp',  assignedTo: 'team_ops', createdAt: daysAgo(0), slaHours: 4,  notes: [{ by: 'team_sup', text: 'Escalated to ops — looks like an auth caching bug', timestamp: daysAgo(0), internal: true }] }
  ];

  // Operator-side schools' remittance status
  const remittances = [
    { id: uid('rem'), schoolId: 'sch_brightlights', period: 'May 2026', amount: 1695200, status: 'completed', remittedAt: daysAgo(3) },
    { id: uid('rem'), schoolId: 'sch_horizon',      period: 'May 2026', amount: 8420000, status: 'pending' },
    { id: uid('rem'), schoolId: 'sch_excellence',   period: 'May 2026', amount: 3950000, status: 'completed', remittedAt: daysAgo(7) },
    { id: uid('rem'), schoolId: 'sch_montessori',   period: 'May 2026', amount: 1180000, status: 'pending' },
    { id: uid('rem'), schoolId: 'sch_anchor',       period: 'May 2026', amount: 12300000, status: 'completed', remittedAt: daysAgo(2) }
  ];

  // Default feature flags for each school (toggled by platform operator)
  schools.forEach(sch => {
    if (!sch.features) {
      sch.features = {
        whatsapp: true,
        lending: sch.subscriptionPlan !== 'Essential',
        ai: sch.subscriptionPlan === 'Enterprise',
        offline: true,
        transport: false,
        payroll: sch.subscriptionPlan !== 'Essential'
      };
    }
  });

  // Subscription invoices CASPAA sends to schools
  const schoolInvoices = [];
  schools.forEach(sch => {
    if (sch.status === 'suspended') return;
    // Last 3 months
    for (let m = 2; m >= 0; m--) {
      const dueDate = new Date(); dueDate.setMonth(dueDate.getMonth() - m, 5);
      const status = m === 0 ? (sch.status === 'trial' ? 'pending' : 'paid')
                   : m === 1 ? 'paid' : 'paid';
      schoolInvoices.push({
        id: uid('sinv'),
        schoolId: sch.id,
        period: dueDate.toLocaleString('en-GB', { month: 'long', year: 'numeric' }),
        plan: sch.subscriptionPlan,
        amount: sch.monthlyFee,
        status,
        dueDate: dueDate.toISOString().slice(0, 10),
        paidAt: status === 'paid' ? new Date(dueDate.getTime() - 86400000 * 2).toISOString() : null,
        remindersSent: status === 'pending' ? 1 : 0
      });
    }
  });

  // Commissions earned by CASPAA
  const commissions = [];
  // Payment fee commissions (1.5% on each successful transaction)
  transactions.filter(t => t.status === 'successful').forEach(t => {
    commissions.push({ id: uid('cm'), schoolId: t.schoolId, type: 'payment', source: 'Paystack transaction', refId: t.id, amount: Math.round(t.amount * 0.015), timestamp: t.timestamp });
  });
  // Lending commissions (interest on active loans, distributed)
  loans.filter(l => l.status === 'active').forEach(l => {
    const interest = l.totalRepayment - l.amount;
    commissions.push({ id: uid('cm'), schoolId: l.schoolId, type: 'lending', source: `Loan ${l.id.slice(-6)}`, refId: l.id, amount: interest, timestamp: l.approvedAt || now() });
  });
  // A couple of referral commissions to demonstrate
  commissions.push({ id: uid('cm'), schoolId: 'sch_brightlights', type: 'referral', source: 'Referred Horizon International', refId: 'sch_horizon', amount: 50000, timestamp: daysAgo(60) });
  commissions.push({ id: uid('cm'), schoolId: 'sch_horizon',      type: 'referral', source: 'Referred Excellence Group',     refId: 'sch_excellence', amount: 75000, timestamp: daysAgo(45) });

  // Usage events (for Platform Usage Analytics)
  const usageEvents = [];
  const featureNames = ['attendance', 'fees', 'results', 'messages', 'assignments', 'loans', 'dashboard', 'announcements'];
  // ~28 days of synthetic usage data
  for (let d = 27; d >= 0; d--) {
    const date = daysAgo(d);
    schools.forEach(sch => {
      if (sch.status === 'suspended') return;
      const base = Math.max(5, Math.floor(sch.students * 0.7));
      const dau = base + Math.floor(Math.random() * 20);
      featureNames.forEach(f => {
        usageEvents.push({ date, schoolId: sch.id, feature: f, count: Math.floor(Math.random() * (f === 'dashboard' ? 200 : 80)) + 5, dau });
      });
    });
  }

  // System / API event logs
  const errorLogs = [
    { id: uid('err'), timestamp: daysAgo(0),  level: 'warning', source: 'paystack-webhook', message: 'Retry: webhook signature mismatch on event evt_xJ8a (auto-retried)', resolved: true },
    { id: uid('err'), timestamp: daysAgo(1),  level: 'error',   source: 'sms-gateway',       message: 'SMS gateway disabled per platform decision (legacy code path)', resolved: true },
    { id: uid('err'), timestamp: daysAgo(2),  level: 'warning', source: 'csv-import',        message: 'Bulk upload at Horizon: 3 rows skipped due to invalid DOB format', resolved: true },
    { id: uid('err'), timestamp: daysAgo(3),  level: 'info',    source: 'auth',              message: 'Unusual login location for sch_montessori admin (Abuja IP) — verified by 2FA', resolved: true },
    { id: uid('err'), timestamp: daysAgo(5),  level: 'error',   source: 'db-replica',        message: 'Replica lag spiked to 3.2s for 90s window — failover not triggered', resolved: true },
    { id: uid('err'), timestamp: daysAgo(7),  level: 'warning', source: 'whatsapp-api',      message: 'Rate-limited at 80 msg/min during PTA broadcast', resolved: true }
  ];

  // Academic sessions + terms + arms
  const academicSessions = [
    { id: 'sess_2024_25', schoolId, name: '2024/2025', startDate: '2024-09-09', endDate: '2025-07-25', current: false },
    { id: 'sess_2025_26', schoolId, name: '2025/2026', startDate: '2025-09-08', endDate: '2026-07-24', current: true }
  ];
  const academicTerms = [
    { id: 'term_1', schoolId, sessionId: 'sess_2025_26', name: '1st Term',   startDate: '2025-09-08', endDate: '2025-12-12', current: true },
    { id: 'term_2', schoolId, sessionId: 'sess_2025_26', name: '2nd Term',   startDate: '2026-01-12', endDate: '2026-04-03', current: false },
    { id: 'term_3', schoolId, sessionId: 'sess_2025_26', name: '3rd Term',   startDate: '2026-04-27', endDate: '2026-07-24', current: false }
  ];
  const arms = [
    { id: 'arm_a', schoolId, name: 'A' },
    { id: 'arm_b', schoolId, name: 'B' },
    { id: 'arm_silver', schoolId, name: 'Silver' },
    { id: 'arm_gold', schoolId, name: 'Gold' }
  ];

  // Academic calendar events
  const academicCalendar = [
    { id: uid('cal'), schoolId, title: 'Mid-term Break',         date: daysAhead(5),   type: 'break',     audience: 'all' },
    { id: uid('cal'), schoolId, title: 'PTA Meeting',             date: daysAhead(8),   type: 'meeting',   audience: 'parents' },
    { id: uid('cal'), schoolId, title: 'Inter-house Sports Day',  date: daysAhead(14),  type: 'event',     audience: 'all' },
    { id: uid('cal'), schoolId, title: 'End of 1st Term Exams',   date: daysAhead(21),  type: 'exam',      audience: 'students' },
    { id: uid('cal'), schoolId, title: '1st Term Ends',           date: '2025-12-12',   type: 'milestone', audience: 'all' },
    { id: uid('cal'), schoolId, title: 'Christmas Break Begins',  date: '2025-12-13',   type: 'break',     audience: 'all' },
    { id: uid('cal'), schoolId, title: '2nd Term Resumption',     date: '2026-01-12',   type: 'milestone', audience: 'all' }
  ];

  // ============ SCHEMES OF WORK (real curriculum) ============
  // For each subject × class × term, a week-by-week topic plan. Schools start from
  // NERDC/UBEC templates and customise. Teachers tick weeks off as they cover them.
  const mkScheme = (subjectId, classId, term, source, weeks) => ({
    id: uid('sch'), schoolId,
    subjectId, classId, term,
    sessionId: 'sess_2025_26',
    source,        // 'NERDC' | 'WAEC' | 'custom'
    status: 'published',
    weeks: weeks.map((w, idx) => ({
      week: idx + 1,
      topic: w.t,
      subtopics: w.s || [],
      objectives: w.o || '',
      methods: w.m || 'Lecture, examples, group work',
      resources: w.r || 'Approved textbook',
      duration: w.d || '3 periods',
      covered: w.covered || false,
      coveredAt: w.covered ? daysAgo(50 - idx * 4) : null,
      coveredBy: null
    })),
    createdAt: daysAgo(80),
    publishedAt: daysAgo(78)
  });

  const schemesOfWork = [
    // ============ JSS 1 — 1st Term ============
    mkScheme('sub_math', 'cls_jss1', '1st Term 2025/26', 'NERDC', [
      { t: 'Whole Numbers', s: ['Counting and writing numbers', 'Place values', 'Reading and writing in words'], o: 'Identify, read and write whole numbers up to 1 billion in words and figures.', covered: true },
      { t: 'LCM and HCF',   s: ['Prime factors', 'LCM by factors and division', 'HCF and applications'], o: 'Find LCM and HCF of any 2-3 numbers using two methods.', covered: true },
      { t: 'Fractions',     s: ['Types of fractions', 'Equivalent fractions', 'Conversion'], o: 'Convert between proper, improper, mixed and decimal fractions.', covered: true },
      { t: 'Decimals and Approximations', s: ['Place values to thousandths', 'Rounding', 'Significant figures'], o: 'Approximate to nearest 10/100/1000 and to significant figures.', covered: true },
      { t: 'Number Bases',  s: ['Base 2, 8, 10', 'Conversion between bases', 'Addition in non-decimal bases'], o: 'Convert numbers between binary, octal, and decimal.', covered: true },
      { t: 'Addition and Subtraction', s: ['Whole numbers', 'Decimals', 'Word problems'], o: 'Solve real-life word problems involving addition/subtraction.', covered: true },
      { t: 'Multiplication and Division', s: ['Whole numbers', 'Decimals', 'Word problems'], o: 'Apply multiplication and division to everyday situations.', covered: true },
      { t: 'Estimation', s: ['Estimation in addition/subtraction', 'Estimation in multiplication/division'], o: 'Estimate sums, differences, products and quotients reliably.', covered: false },
      { t: 'Use of Symbols (Variables)', s: ['Letters as numbers', 'Algebraic expressions'], o: 'Translate verbal statements to algebraic expressions.', covered: false },
      { t: 'Simple Equations', s: ['One-variable equations', 'Solving by inspection', 'Word problems'], o: 'Solve simple linear equations in one variable.', covered: false },
      { t: 'Revision', s: ['Test review', 'Past questions practice'], o: 'Consolidate term concepts in preparation for exam.', covered: false },
      { t: 'Term Examination', s: ['Written test'], o: 'End of term assessment.', covered: false }
    ]),
    mkScheme('sub_eng', 'cls_jss1', '1st Term 2025/26', 'NERDC', [
      { t: 'Reading Comprehension', s: ['Skimming and scanning', 'Main ideas vs details'], o: 'Read short passages and answer literal & inferential questions.', covered: true },
      { t: 'Parts of Speech (Nouns)', s: ['Types of nouns', 'Singular and plural', 'Possessive forms'], o: 'Identify and correctly use the eight parts of speech, starting with nouns.', covered: true },
      { t: 'Parts of Speech (Pronouns)', s: ['Personal pronouns', 'Possessive pronouns', 'Reflexive pronouns'], o: 'Substitute nouns with appropriate pronouns in sentences.', covered: true },
      { t: 'Sentence Structure', s: ['Subject and predicate', 'Simple sentences', 'Sentence types'], o: 'Build simple sentences with clear subject-verb agreement.', covered: true },
      { t: 'Descriptive Writing', s: ['Adjectives', 'Imagery', 'Describing places, people, objects'], o: 'Write a 100-150 word descriptive paragraph.', covered: false },
      { t: 'Letter Writing — Informal', s: ['Format of informal letter', 'Tone', 'Practice'], o: 'Write a coherent informal letter to a friend or relative.', covered: false },
      { t: 'Verbs — Tenses', s: ['Present, past, future', 'Continuous and perfect aspects'], o: 'Use the four major English tenses correctly in writing.', covered: false },
      { t: 'Listening Comprehension', s: ['Identifying tone', 'Note-taking from oral text'], o: 'Take coherent notes from a 3-minute oral passage.', covered: false },
      { t: 'Speech Work — Vowel Sounds', s: ['/ɪ/ vs /iː/', '/e/ vs /æ/'], o: 'Distinguish short and long vowel sounds in pronunciation.', covered: false },
      { t: 'Spelling and Vocabulary', s: ['Word formation', 'Prefixes and suffixes'], o: 'Build vocabulary through prefixes and suffixes.', covered: false },
      { t: 'Revision', s: ['Reading + writing practice'], o: 'Consolidate term skills.', covered: false },
      { t: 'Term Examination', s: ['Written test'], o: 'End of term assessment.', covered: false }
    ]),
    // ============ JSS 1 — Basic Science ============
    mkScheme('sub_sci', 'cls_jss1', '1st Term 2025/26', 'NERDC', [
      { t: 'You and Your Environment', s: ['Living vs non-living things', 'Habitat'], o: 'Classify items in the environment as living/non-living.', covered: true },
      { t: 'Human Body Systems — Overview', s: ['Skeletal', 'Muscular', 'Digestive', 'Respiratory'], o: 'Name the major systems of the human body and their functions.', covered: true },
      { t: 'Reproductive System and Puberty', s: ['Changes in puberty', 'Personal hygiene'], o: 'Discuss puberty changes with maturity and accurate vocabulary.', covered: true },
      { t: 'Drugs and Substance Abuse', s: ['Common drugs', 'Effects of abuse', 'Avoidance'], o: 'Identify drugs commonly abused and their effects on the body.', covered: false },
      { t: 'Matter — States and Properties', s: ['Solid, liquid, gas', 'Phase changes'], o: 'Describe the three states of matter and the changes between them.', covered: false },
      { t: 'Air', s: ['Composition', 'Atmospheric pressure', 'Air pollution'], o: 'List the major gases in air and discuss pollution.', covered: false },
      { t: 'Water', s: ['Sources', 'Properties', 'Treatment of water'], o: 'Explain the water cycle and basic treatment methods.', covered: false },
      { t: 'Energy', s: ['Forms of energy', 'Renewable vs non-renewable'], o: 'Identify common energy sources and classify them.', covered: false },
      { t: 'Simple Machines', s: ['Levers', 'Pulleys', 'Inclined planes'], o: 'Identify simple machines around the home and school.', covered: false },
      { t: 'Computing Devices (Intro)', s: ['Parts of a computer', 'Uses'], o: 'Name and describe the basic parts of a computer.', covered: false },
      { t: 'Revision', s: ['Q&A across topics'], o: 'Consolidate term concepts.', covered: false },
      { t: 'Term Examination', s: ['Written test'], o: 'End of term assessment.', covered: false }
    ]),
    // ============ Primary 3 — Mathematics ============
    mkScheme('sub_math', 'cls_pry3', '1st Term 2025/26', 'UBEC', [
      { t: 'Counting up to 9,999', s: ['Place values', 'Reading and writing'], o: 'Read and write numbers up to 9,999.', covered: true },
      { t: 'Roman Numerals to 50', s: ['Symbols I, V, X, L', 'Conversion'], o: 'Convert between Roman and Arabic up to 50.', covered: true },
      { t: 'Addition without Regrouping', s: ['3-digit + 3-digit', 'Word problems'], o: 'Add 3-digit numbers correctly without regrouping.', covered: true },
      { t: 'Addition with Regrouping', s: ['Carrying over', 'Word problems'], o: 'Add numbers requiring carry-over.', covered: false },
      { t: 'Subtraction', s: ['Without regrouping', 'With regrouping'], o: 'Subtract numbers up to 3 digits accurately.', covered: false },
      { t: 'Multiplication Tables 2-9', s: ['Memorisation', 'Application'], o: 'Recite and apply multiplication tables 2 through 9.', covered: false },
      { t: 'Division', s: ['Sharing concept', 'Simple division'], o: 'Solve simple division problems with no remainder.', covered: false },
      { t: 'Money', s: ['Naira notes and kobo', 'Addition of money'], o: 'Add and subtract amounts of money correctly.', covered: false },
      { t: 'Length', s: ['Metres and centimetres', 'Measuring'], o: 'Measure and convert between metres and centimetres.', covered: false },
      { t: 'Time', s: ['Reading clocks', 'Days, weeks, months'], o: 'Tell time on analog and digital clocks.', covered: false },
      { t: 'Revision', s: ['Worksheets and practice'], o: 'Consolidate.', covered: false },
      { t: 'Term Examination', s: ['Written test'], o: 'End of term.', covered: false }
    ])
  ];

  // Per-school role catalog (RBAC) — predefined roles + room for custom ones
  const schoolRoles = [
    { id: 'role_proprietor', schoolId, name: 'Proprietor',     description: 'Full system control. Cannot be deleted.', system: true,  permissions: ['*'],                                                                            color: '#7c3aed' },
    { id: 'role_principal',  schoolId, name: 'Principal',      description: 'Academic + administrative oversight, no finance.', system: true,  permissions: ['students','staff','academic','attendance','results','discipline','admissions','alumni','sickbay','communications'], color: '#0ea5e9' },
    { id: 'role_vp',         schoolId, name: 'Vice Principal', description: 'Same as Principal, secondary signatory.',          system: false, permissions: ['students','staff','academic','attendance','results','discipline','admissions','sickbay','communications'], color: '#06b6d4' },
    { id: 'role_bursar',     schoolId, name: 'Bursar',         description: 'Fees, invoices, financial reports.',                system: true,  permissions: ['fees','invoices','payments','reports','reconciliation'], color: '#f59e0b' },
    { id: 'role_hod',        schoolId, name: 'Head of Dept.',  description: 'Manage subject curriculum + teachers within a department.', system: false, permissions: ['curriculum','results','attendance','communications'], color: '#10b981' },
    { id: 'role_teacher',    schoolId, name: 'Teacher',        description: 'Mark attendance, enter results, post assignments.', system: true,  permissions: ['attendance','results','assignments','lesson_plans','messaging'],     color: '#059669' },
    { id: 'role_form_t',     schoolId, name: 'Form Teacher',   description: 'Teacher + own-class daily attendance + discipline.', system: false, permissions: ['attendance','results','assignments','lesson_plans','messaging','discipline'], color: '#22c55e' },
    { id: 'role_librarian',  schoolId, name: 'Librarian',      description: 'Manage library catalog and loans.',                 system: false, permissions: ['library'],                                                color: '#a855f7' },
    { id: 'role_nurse',      schoolId, name: 'School Nurse',   description: 'Sick bay records and parent health notifications.', system: false, permissions: ['sickbay','communications'],                                color: '#ef4444' },
    { id: 'role_security',   schoolId, name: 'Security',       description: 'Visitor log and gate control.',                     system: false, permissions: ['visitors'],                                                color: '#6b7280' },
    { id: 'role_parent',     schoolId, name: 'Parent',         description: 'View own child(ren) only.',                         system: true,  permissions: ['own_children','own_fees','messaging'],                     color: '#0891b2' }
  ];

  // CASPAA team members (platform side)
  const platformTeam = [
    { id: 'sa_001',   role: 'Super Admin',     name: 'Tayo Adesola',     email: 'super@caspaa.com',         permissions: ['*'],                                                          createdAt: daysAgo(400), lastActive: now() },
    { id: 'team_ops', role: 'Operations',      name: 'Adaeze Okeke',     email: 'ops@caspaa.com',           permissions: ['schools', 'support', 'audit'],                                createdAt: daysAgo(300), lastActive: daysAgo(0) },
    { id: 'team_fin', role: 'Finance',         name: 'Mohammed Bello',   email: 'finance@caspaa.com',       permissions: ['revenue', 'invoices', 'commissions'],                          createdAt: daysAgo(280), lastActive: daysAgo(0) },
    { id: 'team_cre', role: 'Credit',          name: 'Chinwe Nwosu',     email: 'credit@caspaa.com',        permissions: ['lending', 'disbursement'],                                     createdAt: daysAgo(220), lastActive: daysAgo(1) },
    { id: 'team_rsk', role: 'Risk',            name: 'Funke Ayodeji',    email: 'risk@caspaa.com',          permissions: ['lending', 'audit', 'analytics'],                               createdAt: daysAgo(200), lastActive: daysAgo(0) },
    { id: 'team_sup', role: 'Support',         name: 'Tunde Adekunle',   email: 'support@caspaa.com',       permissions: ['support', 'schools'],                                          createdAt: daysAgo(150), lastActive: daysAgo(0) },
    { id: 'team_com', role: 'Compliance',      name: 'Ngozi Eboh',       email: 'compliance@caspaa.com',    permissions: ['audit', 'security'],                                           createdAt: daysAgo(120), lastActive: daysAgo(2) },
    { id: 'team_bi',  role: 'BI / Analytics',  name: 'Segun Adeyinka',   email: 'bi@caspaa.com',            permissions: ['analytics', 'revenue'],                                        createdAt: daysAgo(90),  lastActive: daysAgo(0) }
  ];

  // School branding defaults
  schools.forEach(s => {
    if (!s.branding) s.branding = {
      primaryColor: s.id === 'sch_brightlights' ? '#047857' : (s.id === 'sch_horizon' ? '#1e40af' : '#0f766e'),
      logoText: s.name.split(' ').map(w => w[0]).join('').slice(0, 3).toUpperCase(),
      motto: s.id === 'sch_brightlights' ? 'Light the way to knowledge' : (s.id === 'sch_horizon' ? 'Reaching beyond horizons' : 'Excellence in education'),
      logoImage: null
    };
  });

  // Login sessions / device tracking
  const loginSessions = [
    { id: uid('sess'), userId: 'sch_brightlights', device: 'Chrome on Windows 11',  ip: '102.89.34.12',  location: 'Lagos, Nigeria', loggedInAt: now(),           current: true,  twoFA: true },
    { id: uid('sess'), userId: 'sch_brightlights', device: 'Safari on iPhone 14',   ip: '197.210.55.4',  location: 'Lagos, Nigeria', loggedInAt: daysAgo(0),      current: false, twoFA: true },
    { id: uid('sess'), userId: 'sch_brightlights', device: 'Chrome on Android',     ip: '197.210.78.9',  location: 'Ibadan, Nigeria', loggedInAt: daysAgo(2),    current: false, twoFA: true },
    { id: uid('sess'), userId: 'sa_001',           device: 'Chrome on macOS',       ip: '105.112.30.8',  location: 'Lagos, Nigeria', loggedInAt: now(),           current: true,  twoFA: true },
    { id: uid('sess'), userId: 'tch_adamu',        device: 'Chrome on Android',     ip: '197.210.55.55', location: 'Lagos, Nigeria', loggedInAt: daysAgo(0),      current: true,  twoFA: false }
  ];

  // Sick Bay / health records
  const sickBayRecords = [
    { id: uid('sb'), schoolId, studentId: 'stu_002', complaint: 'Headache and slight fever',     temperature: 37.8, treatment: 'Paracetamol 250mg, rest in clinic', referredToHospital: false, attendedBy: 'School Nurse', date: daysAgo(2), parentNotified: true },
    { id: uid('sb'), schoolId, studentId: 'stu_005', complaint: 'Minor knee scrape during sport', temperature: 36.5, treatment: 'Cleaned and bandaged',                referredToHospital: false, attendedBy: 'School Nurse', date: daysAgo(4), parentNotified: true },
    { id: uid('sb'), schoolId, studentId: 'stu_009', complaint: 'Severe stomach pain',           temperature: 38.2, treatment: 'Referred to hospital — parent collected', referredToHospital: true,  attendedBy: 'School Nurse', date: daysAgo(8), parentNotified: true }
  ];

  // Visitor / Gate log
  const visitorLog = [
    { id: uid('vis'), schoolId, visitor: 'Mrs. Felicia Ojo',     toSee: 'Mrs. Bola Akinwale', relation: 'Parent of Fatima Musa', phone: '08099123450', purpose: 'Discuss daughter\'s progress', checkIn: daysAgo(0) + 'T09:15', checkOut: daysAgo(0) + 'T10:02', vehicle: 'Toyota Camry LSD-241-AB' },
    { id: uid('vis'), schoolId, visitor: 'GTBank Sales Rep',     toSee: 'Mr. Olusegun Adebayo', relation: 'Vendor',                phone: '08099123451', purpose: 'School account package',         checkIn: daysAgo(1) + 'T11:00', checkOut: daysAgo(1) + 'T11:45', vehicle: 'Honda Accord' },
    { id: uid('vis'), schoolId, visitor: 'Mr. Sunday Adeleke',   toSee: 'Mr. Adamu Ibrahim',   relation: 'Maintenance',           phone: '08099123452', purpose: 'AC servicing for JSS classes',   checkIn: daysAgo(2) + 'T08:30', checkOut: daysAgo(2) + 'T14:20', vehicle: 'Foot' }
  ];

  // Library catalog (books with borrow tracking)
  const libraryBooks = [
    { id: uid('book'), schoolId, title: 'The Joys of Motherhood',     author: 'Buchi Emecheta',          isbn: '978-0-435-90972-2', category: 'Fiction',  copiesTotal: 5, copiesAvailable: 3, location: 'Shelf A-12' },
    { id: uid('book'), schoolId, title: 'Things Fall Apart',          author: 'Chinua Achebe',           isbn: '978-0-385-47454-2', category: 'Fiction',  copiesTotal: 8, copiesAvailable: 5, location: 'Shelf A-01' },
    { id: uid('book'), schoolId, title: 'New General Mathematics SS1', author: 'M.F. Macrae',             isbn: '978-129-220-052-4', category: 'Maths',    copiesTotal: 30, copiesAvailable: 22, location: 'Shelf C-04' },
    { id: uid('book'), schoolId, title: 'Lamb to the Slaughter',      author: 'Roald Dahl',              isbn: '978-014-100-148-0', category: 'Fiction',  copiesTotal: 6, copiesAvailable: 6, location: 'Shelf A-15' },
    { id: uid('book'), schoolId, title: 'Atlas of Africa',            author: 'Macmillan Reference',     isbn: '978-023-022-941-1', category: 'Reference', copiesTotal: 4, copiesAvailable: 4, location: 'Shelf B-02' },
    { id: uid('book'), schoolId, title: 'STAN Integrated Science',    author: 'STAN',                    isbn: '978-979-302-181-8', category: 'Science',  copiesTotal: 25, copiesAvailable: 18, location: 'Shelf C-08' }
  ];
  const libraryLoans = [
    { id: uid('lln'), schoolId, bookId: libraryBooks[0].id, studentId: 'stu_003', borrowedAt: daysAgo(5),  dueDate: daysAhead(9),  returnedAt: null },
    { id: uid('lln'), schoolId, bookId: libraryBooks[1].id, studentId: 'stu_008', borrowedAt: daysAgo(3),  dueDate: daysAhead(11), returnedAt: null },
    { id: uid('lln'), schoolId, bookId: libraryBooks[0].id, studentId: 'stu_002', borrowedAt: daysAgo(15), dueDate: daysAgo(1),    returnedAt: null }, // overdue
    { id: uid('lln'), schoolId, bookId: libraryBooks[2].id, studentId: 'stu_009', borrowedAt: daysAgo(20), dueDate: daysAgo(6),    returnedAt: daysAgo(5) }
  ];

  // Admission applications (public-facing → admin review queue)
  const admissionApplications = [
    {
      id: 'app_001', schoolId, applicantName: 'Tomide Ogunlana',  parentName: 'Mr. Yinka Ogunlana', parentPhone: '08099234501', parentEmail: 'yinka@example.com', dob: '2015-04-10', gender: 'M', requestedClass: 'cls_pry3', currentSchool: 'Holy Trinity Nursery',   reason: 'Family relocated to Lekki', status: 'pending',  appliedAt: daysAgo(1),
      documents: {
        birthCert:    { name: 'birth-certificate-tomide.pdf', type: 'application/pdf', size: '142 KB', uploaded: true },
        parentId:     { name: 'NIN-ogunlana.jpg', type: 'image/jpeg', size: '96 KB', uploaded: true },
        immunization: { name: 'immunization-record.pdf', type: 'application/pdf', size: '210 KB', uploaded: true },
        photo:        null
      }
    },
    {
      id: 'app_002', schoolId, applicantName: 'Chinaza Okonkwo',  parentName: 'Mrs. Ada Okonkwo',   parentPhone: '08099234502', parentEmail: 'ada@example.com',   dob: '2012-09-22', gender: 'F', requestedClass: 'cls_jss1', currentSchool: 'Greengates Academy',     reason: 'Better academic reputation', status: 'reviewing', appliedAt: daysAgo(3),
      documents: {
        birthCert: { name: 'chinaza-bcert.pdf', type: 'application/pdf', size: '128 KB', uploaded: true },
        parentId:  { name: 'mom-license.jpg',    type: 'image/jpeg',     size: '88 KB',  uploaded: true },
        immunization: null,
        photo:     { name: 'chinaza-passport.jpg', type: 'image/jpeg', size: '54 KB', uploaded: true }
      }
    },
    {
      id: 'app_003', schoolId, applicantName: 'Ibrahim Garba',    parentName: 'Mr. Musa Garba',     parentPhone: '08099234503', parentEmail: 'musa@example.com',  dob: '2010-11-30', gender: 'M', requestedClass: 'cls_sss1', currentSchool: 'Mufti Memorial College', reason: 'Sports scholarship interest', status: 'accepted', appliedAt: daysAgo(10), decidedAt: daysAgo(5),
      documents: {
        birthCert: { name: 'garba-birth.pdf', type: 'application/pdf', size: '156 KB', uploaded: true },
        parentId:  { name: 'musa-NIN.pdf', type: 'application/pdf', size: '102 KB', uploaded: true },
        immunization: { name: 'immunization-garba.pdf', type: 'application/pdf', size: '198 KB', uploaded: true },
        photo:     { name: 'ibrahim-passport.jpg', type: 'image/jpeg', size: '68 KB', uploaded: true }
      }
    }
  ];

  // Substitute teacher coverage
  const substituteCoverage = []; // populated dynamically when leave is approved

  // Payroll runs — 4-stage flow: draft → pending_approval → approved → paid
  const _lastMonth = new Date(); _lastMonth.setMonth(_lastMonth.getMonth() - 1);
  const _thisMonth = new Date();
  const _lastMonthLabel = _lastMonth.toLocaleString('en-GB', { month: 'long', year: 'numeric' });
  const _thisMonthLabel = _thisMonth.toLocaleString('en-GB', { month: 'long', year: 'numeric' });
  const _payrollBase = teachers.reduce((s, t) => s + (t.salary || 0), 0);
  // PAYE ~7%, Pension ~8% (employee 8% + employer 10% in NG, simplified)
  const _payeRate = 0.07;
  const _pensionEmployeeRate = 0.08;

  const payrollRuns = [
    {
      id: uid('pr'), schoolId, period: _lastMonthLabel,
      stage: 'paid',
      grossTotal: _payrollBase,
      netTotal: Math.round(_payrollBase * (1 - _payeRate - _pensionEmployeeRate)),
      payeTotal: Math.round(_payrollBase * _payeRate),
      pensionTotal: Math.round(_payrollBase * _pensionEmployeeRate),
      staffCount: teachers.length,
      adjustments: [],
      computedAt: daysAgo(35),
      submittedAt: daysAgo(34),
      approvedAt: daysAgo(33),
      paidAt: daysAgo(32),
      computedBy: 'sch_brightlights', submittedBy: 'sch_brightlights', approvedBy: 'sch_brightlights', paidBy: 'sch_brightlights',
      taxRemitted: true, pensionRemitted: true
    },
    {
      id: uid('pr'), schoolId, period: _thisMonthLabel,
      stage: 'draft',
      grossTotal: _payrollBase,
      netTotal: Math.round(_payrollBase * (1 - _payeRate - _pensionEmployeeRate)),
      payeTotal: Math.round(_payrollBase * _payeRate),
      pensionTotal: Math.round(_payrollBase * _pensionEmployeeRate),
      staffCount: teachers.length,
      adjustments: [
        { staffId: 'tch_adamu',  type: 'bonus',     amount: 25000,  note: 'Best teacher award' },
        { staffId: 'stf_sec',    type: 'overtime',  amount: 8000,   note: 'Saturday duty x 2' },
        { staffId: 'tch_chioma', type: 'deduction', amount: -5000,  note: 'Late arrivals (3 days)' }
      ],
      computedAt: now(),
      computedBy: 'sch_brightlights'
    }
  ];

  // Disbursements ledger (operator-controlled loan payouts to schools)
  const disbursements = [];
  loans.filter(l => l.status === 'active' && l.approvedAt).forEach(l => {
    const sch = schools.find(s => s.id === l.schoolId);
    disbursements.push({
      id: uid('dsb'),
      loanId: l.id,
      schoolId: l.schoolId,
      recipientName: sch ? sch.name : '—',
      recipientAccount: '01' + Math.random().toString().slice(2, 10),
      amount: l.amount,
      status: 'completed',
      method: 'NIBSS transfer',
      reference: 'DSB-' + Math.random().toString(36).slice(2, 10).toUpperCase(),
      initiatedAt: l.approvedAt,
      completedAt: l.approvedAt,
      verifiedBy: 'sa_001'
    });
  });

  // System performance metrics (running averages, last 30 days)
  const systemMetrics = {
    apiUptime: 99.92,
    avgResponseMs: 187,
    failedPaymentRate: 2.7,
    crashFreeSessions: 99.7,
    p95ResponseMs: 412,
    backupsLast24h: 1,
    incidentsOpen: 0
  };

  return {
    schools, classes, subjects, teachers, parents, students,
    feeStructures, invoices, transactions, attendance, results,
    assignments, conversations, announcements, inventory,
    discipline, loans, timetable, lessonPlans, expenses,
    auditLog, notifications, leaveRequests, staffAttendance,
    supportTickets, remittances,
    schoolInvoices, commissions, usageEvents, errorLogs, systemMetrics,
    disbursements,
    academicSessions, academicTerms, arms, academicCalendar, platformTeam, schoolRoles, payrollRuns,
    schemesOfWork,
    loginSessions, sickBayRecords, visitorLog,
    libraryBooks, libraryLoans, admissionApplications, substituteCoverage,
    settings: {
      currentSchoolId: 'sch_brightlights',
      currentTerm: '1st Term 2025/26',
      currency: 'NGN',
      gradeScale: [
        { min: 75, grade: 'A', remark: 'Excellent' },
        { min: 60, grade: 'B', remark: 'Very Good' },
        { min: 50, grade: 'C', remark: 'Good' },
        { min: 45, grade: 'D', remark: 'Fair' },
        { min: 40, grade: 'E', remark: 'Pass' },
        { min: 0,  grade: 'F', remark: 'Fail' }
      ],
      offlineMode: false,
      pendingSync: 0
    }
  };
}

/* ---------- DB Interface ---------- */
const DB = {
  _data: null,
  load() {
    if (this._data) return this._data;
    const raw = localStorage.getItem(DB_KEY);
    if (raw) {
      try { this._data = JSON.parse(raw); return this._data; }
      catch (e) { console.warn('DB corrupt, reseeding'); }
    }
    this._data = seedDatabase();
    this.save();
    return this._data;
  },
  save() { localStorage.setItem(DB_KEY, JSON.stringify(this._data)); },
  reset() { localStorage.removeItem(DB_KEY); this._data = null; this.load(); },
  get(table) { return (this.load()[table] || []).slice(); },
  set(table, rows) { this.load()[table] = rows; this.save(); },
  insert(table, row) {
    const d = this.load();
    if (!d[table]) d[table] = [];
    d[table].push(row);
    this.save();
    return row;
  },
  update(table, id, patch) {
    const d = this.load();
    if (!d[table]) return null;
    const idx = d[table].findIndex(r => r.id === id);
    if (idx === -1) return null;
    d[table][idx] = { ...d[table][idx], ...patch };
    this.save();
    return d[table][idx];
  },
  remove(table, id) {
    const d = this.load();
    if (!d[table]) return;
    d[table] = d[table].filter(r => r.id !== id);
    this.save();
  },
  find(table, id) {
    const t = this.load()[table];
    if (!t) return undefined;
    return t.find(r => r.id === id);
  },
  query(table, predicate) {
    const t = this.load()[table];
    if (!t) return [];
    return t.filter(predicate);
  },
  settings(patch) {
    const d = this.load();
    if (patch) { d.settings = { ...d.settings, ...patch }; this.save(); }
    return d.settings;
  }
};

/* ---------- Computed helpers ---------- */
const COMPUTE = {
  studentsByClass(classId) { return DB.query('students', s => s.classId === classId && s.status === 'active'); },
  parentChildren(parentId) { return DB.query('students', s => s.parentId === parentId); },
  studentInvoice(studentId) { return DB.query('invoices', i => i.studentId === studentId)[0]; },
  studentResults(studentId) { return DB.query('results', r => r.studentId === studentId); },
  studentAttendance(studentId) { return DB.query('attendance', a => a.studentId === studentId); },
  attendanceRate(studentId) {
    const recs = this.studentAttendance(studentId);
    if (!recs.length) return 0;
    const present = recs.filter(r => r.status !== 'absent').length;
    return Math.round((present / recs.length) * 100);
  },
  classAttendance(classId, date) {
    return DB.query('attendance', a => a.classId === classId && a.date === date);
  },
  parentLoans(parentId) { return DB.query('loans', l => l.parentId === parentId); },
  conversationsFor(userId) {
    return DB.query('conversations', c => c.participants.includes(userId));
  },
  unreadCount(userId) {
    return DB.query('notifications', n => n.userId === userId && !n.read).length;
  },
  // Financial summary
  schoolRevenue(schoolId) {
    const txns = DB.query('transactions', t => t.schoolId === schoolId && t.status === 'successful');
    return txns.reduce((s, t) => s + t.amount, 0);
  },
  schoolExpenses(schoolId) {
    return DB.query('expenses', e => e.schoolId === schoolId).reduce((s, e) => s + e.amount, 0);
  },
  outstandingFees(schoolId) {
    return DB.query('invoices', i => i.schoolId === schoolId).reduce((s, i) => s + i.balance, 0);
  },
  // Credit scoring
  computeCreditScore(parentId) {
    const txns = DB.query('transactions', t => DB.query('invoices', i => i.studentId).map(i => i.id).includes(t.invoiceId));
    const inv = DB.query('invoices', i => {
      const s = DB.find('students', i.studentId);
      return s && s.parentId === parentId;
    });
    if (!inv.length) return 600;
    const onTime = inv.filter(i => i.status === 'paid').length;
    const partial = inv.filter(i => i.status === 'partial').length;
    const outstanding = inv.filter(i => i.status === 'outstanding').length;
    const parent = DB.find('parents', parentId);
    let score = 600;
    score += onTime * 50;
    score += partial * 20;
    score -= outstanding * 30;
    if (parent && parent.monthlyIncome > 500000) score += 40;
    if (parent && parent.monthlyIncome > 1000000) score += 30;
    // Tenure bonus
    score += 20;
    return Math.max(300, Math.min(850, score));
  },
  // Grade from total score
  gradeFromScore(total) {
    const scale = DB.settings().gradeScale;
    for (const s of scale) if (total >= s.min) return { grade: s.grade, remark: s.remark };
    return { grade: 'F', remark: 'Fail' };
  }
};

// Init on load
DB.load();
